"""LLM serving, batching, tail-latency, and inference-scaling solvers.

Domain implementations behind ``mlsysim.solvers`` (the public import
path, derived from ``engine.solvers.__init__``); kept per-domain so the logic stays reviewable.
"""

from __future__ import annotations

import math
from typing import Optional

from ..results import (
    ServingResult,
    ServingCapacityResult,
    ContinuousBatchingResult,
    WeightStreamingResult,
    TailLatencyResult,
    InferenceScalingResult,
    BatchingOptimizerResult,
)
from ...core.units import ureg, Q_, resolve_precision
from .. import calibration as cal
from ...core.types import Quantity
from ...models.types import TransformerWorkload
from ...physics.transformer import calc_attention_matmul_flops, calc_transformer_decode_flops
from ...physics.memory import calc_kv_cache_size
from ...hardware.types import HardwareNode
from .base import BaseOptimizer, ForwardModel
from ._decode import decode_step as _decode_step
from ...core._validation import validate_at_least, validate_positive, validate_range


class ServingModel(ForwardModel):
    """
    Analyzes the two-phase LLM serving lifecycle: Pre-fill vs. Decoding.

    LLM inference is not a single mathematical operation; it is a stateful
    process with two phases. Prefill is modeled with a compute bound; decode
    compares compute and memory bounds because the limiting resource depends
    on batch size and context length.

    Literature Source:
    1. Pope et al. (2023), "Efficiently Scaling Transformer Inference."
    2. Agrawal et al. (2024), "Sarathi-Serve" (chunked prefill scheduling).
    3. Patel et al. (2024), "Splitwise" and Zhong et al. (2024),
       "DistServe" (prefill/decode disaggregation).

    Formula contract:
    - TTFT is prefill compute over new prompt tokens plus dispatch overhead and,
      for disaggregated serving, KV-transfer time.
    - ITL is max(decode compute time, weight/KV memory time), plus the
      configured framework layer tax. Efficiency derates compute only.
    - KV memory always covers the full sequence, even when prompt caching skips
      part of the prefill computation.
    """

    requires = ("workload", "hardware")
    produces = ServingResult

    def solve(
        self,
        model: TransformerWorkload,
        hardware: HardwareNode,
        seq_len: int,
        batch_size: int = 1,
        precision: str = "fp16",
        efficiency: float = 0.5,
        decode_hardware: Optional[HardwareNode] = None,
        network_bandwidth: Quantity = Q_("100 GB/s"),
        draft_model: Optional[TransformerWorkload] = None,
        draft_acceptance_rate: float = 0.7,
        cached_prefix_len: int = 0,
        prefill_chunk_tokens: Optional[int] = None,
    ) -> ServingResult:
        """Solve for LLM serving performance.

        Parameters
        ----------
        model : TransformerWorkload
            The primary model to be served.
        hardware : HardwareNode
            The hardware node for serving (or pre-fill node in disaggregated serving).
        seq_len : int
            Positive context length in tokens per request, including cached prefix.
        batch_size : int
            Positive simultaneous requests sharing one decode iteration.
        precision : str
            Weight and KV element precision, such as fp16 or int8.
        efficiency : float
            Dimensionless compute fraction in (0, 1]; memory uses peak bandwidth.
        decode_hardware : HardwareNode, optional
            If provided, models Disaggregated Serving where 'hardware' does pre-fill
            and 'decode_hardware' does decoding. KV-cache is transferred over the network.
        network_bandwidth : Quantity
            Positive transfer rate in bytes/time between prefill and decode nodes.
        draft_model : TransformerWorkload, optional
            If provided, models Speculative Decoding using this smaller draft model.
        draft_acceptance_rate : float
            Expected acceptance rate (0.0 to 1.0) of draft tokens per step.
        cached_prefix_len : int
            Nonnegative count of tokens with precomputed KV cache (prefix caching).
            When > 0, the prefill phase only processes (seq_len - cached_prefix_len) new
            tokens, reducing TTFT proportionally. The full KV-cache (including cached prefix)
            still occupies memory. Must be < seq_len.
        prefill_chunk_tokens : int, optional
            If provided, split new prefill tokens into chunks of at most this size. This estimates
            a Sarathi-Serve-style chunked-prefill stall proxy: total TTFT keeps the same compute
            work plus one dispatch tax per chunk, while decode_stall_bound reports the slowest
            single chunk that can interfere with ongoing decode iterations. It is not a full
            scheduler simulation.

        Returns
        -------
        ServingResult
            TTFT and ITL in time units, required memory, and constraint traces.
            Feasibility checks modeled resident storage on each device;
            it does not guarantee a serving engine can deploy the configuration.

        Notes
        -----
        Equation: T_step = max(F_step / (eta * peak), (W + KV) / BW)
        + T_layer. F_step includes linear work and both attention matrix
        products; W is resident weight storage and KV covers all requests.
        The helper shared with ContinuousBatchingModel implements this bound.

        Assumptions: peak memory bandwidth, one weight read per decode step,
        and ideal compute/memory overlap. Efficiency eta changes compute only.
        The per-layer tax is a separate runtime assumption.
        Excludes: runtime workspaces, allocator reserve, and tensor-parallel
        collectives.
        Speculation adds draft weights and KV storage; disaggregation checks
        prefill and decode capacities independently. For K draft proposals,
        target verification evaluates K+1 query positions, including the
        bonus-token distribution, before amortizing by expected output tokens.
        Prefill remains a
        compute-time approximation, not a kernel schedule.

        References
        ----------
        Williams, Waterman, and Patterson (2009), "Roofline: An Insightful
        Visual Performance Model for Multicore Architectures."
        https://doi.org/10.1145/1498765.1498785 (bibliography key: williams2009).
        Pope et al. (2023), "Efficiently Scaling Transformer Inference."
        https://arxiv.org/abs/2211.05102 (bibliography key: pope2023efficiently).
        Leviathan et al. (2023), "Fast Inference from Transformers via
        Speculative Decoding," Algorithm 1 (bibliography key: leviathan2023fast).
        https://arxiv.org/abs/2211.17192.
        These sources motivate the bounds; the layer tax and feasibility
        conventions above are MLSysIM modeling choices.

        Examples
        --------
        >>> from mlsysim import Hardware, Models
        >>> from mlsysim.solvers import ServingModel
        >>> result = ServingModel().solve(
        ...     Models.Language.Llama3_8B, Hardware.Cloud.H100, seq_len=2048)
        >>> bool(result.feasible and result.itl.m_as("ms") > 0)
        True
        """
        precision, bpp = resolve_precision(precision)

        # 0. Input validation
        validate_at_least(seq_len, 1, f"seq_len ({seq_len})")
        validate_at_least(batch_size, 1, f"batch_size ({batch_size})")
        validate_range(efficiency, 1e-9, 1.0, "efficiency")
        validate_at_least(cached_prefix_len, 0, "cached_prefix_len")
        if cached_prefix_len >= seq_len:
            raise ValueError(f"cached_prefix_len ({cached_prefix_len}) must be < seq_len ({seq_len})")
        validate_range(draft_acceptance_rate, 0.0, 1.0, "draft_acceptance_rate")
        if prefill_chunk_tokens is not None:
            validate_at_least(prefill_chunk_tokens, 1, "prefill_chunk_tokens")
        validate_positive(network_bandwidth.to("B/s"), "network_bandwidth")
        validate_positive(hardware.memory.capacity, "prefill memory capacity")
        validate_positive((decode_hardware or hardware).memory.capacity, "decode memory capacity")

        # 1. Pre-fill Phase (with optional prompt caching)
        # Prefer the precision-specific FLOP rate (e.g. FP16 tensor cores); fall back
        # to the generic peak when the registry has no entry for this dtype.
        peak_flops_prefill = hardware.compute.precision_flops.get(precision, hardware.compute.peak_flops)
        # Prompt caching: only new tokens need prefill computation. The max(1, ...)
        # floor keeps the model well-defined even when nearly the whole prompt is
        # cached — at least one token must pass through prefill to produce output.
        new_tokens = max(1, seq_len - cached_prefix_len)
        # Linear layer FLOPs: 2 * params * tokens * batch (standard 2P approximation)
        linear_flops = calc_transformer_decode_flops(model.parameters, new_tokens) * batch_size
        # Both attention matrix products visit the supplied context.
        # This captures the O(S^2) self-attention cost, which dominates for long contexts.
        # getattr-with-fallback tolerates plain Workloads that lack transformer
        # geometry; the `or` guards convert an explicit None into the same default.
        n_layers = getattr(model, "layers", 1) or 1
        n_heads = getattr(model, "heads", 32) or 32
        head_dim = getattr(model, "head_dim", None) or (getattr(model, "hidden_dim", 4096) or 4096) // n_heads
        # Upper-bound approximation: each new token attends over the final context.
        # The leading 4 = 2 FLOPs/MAC x 2 attention matmuls (QK^T scores and
        # attention-weighted V). When cached_prefix_len=0, new_tokens == seq_len
        # so this simplifies to S^2.
        attention_flops = calc_attention_matmul_flops(n_layers, n_heads * head_dim, new_tokens, seq_len, batch_size)
        prefill_ops = linear_flops + attention_flops
        t_prefill_compute = (prefill_ops / (peak_flops_prefill * efficiency)).to("ms")
        prefill_chunks = 1
        prefill_chunk_time: Optional[Quantity] = None
        decode_stall_bound: Optional[Quantity] = None
        if prefill_chunk_tokens is not None:
            # Chunked prefill (Sarathi-Serve): split the prompt into bounded chunks
            # so prefill work can interleave with ongoing decode iterations. Total
            # compute is unchanged; what we gain is a bound on how long any single
            # chunk can stall a decode step.
            prefill_chunks = max(1, math.ceil(new_tokens / prefill_chunk_tokens))
            chunk_times = []
            tokens_remaining = new_tokens
            while tokens_remaining > 0:
                chunk_tokens = min(prefill_chunk_tokens, tokens_remaining)
                chunk_linear = calc_transformer_decode_flops(model.parameters, chunk_tokens) * batch_size
                # Conservative: every chunk's tokens attend over the full final
                # context (seq_len), matching the upper-bound convention above.
                chunk_attention = calc_attention_matmul_flops(
                    n_layers, n_heads * head_dim, chunk_tokens, seq_len, batch_size
                )
                chunk_ops = chunk_linear + chunk_attention
                chunk_time = (chunk_ops / (peak_flops_prefill * efficiency)).to("ms") + hardware.dispatch_tax
                chunk_times.append(chunk_time)
                tokens_remaining -= chunk_tokens
            # The slowest chunk is the worst-case decode interference window.
            prefill_chunk_time = max(chunk_times, key=lambda t: t.to("ms").magnitude)
            decode_stall_bound = prefill_chunk_time
        # One kernel-dispatch tax per chunk: chunking trades extra launch overhead
        # for bounded decode stalls (prefill_chunks == 1 when chunking is off).
        t_prefill = t_prefill_compute + (hardware.dispatch_tax * prefill_chunks)

        # KV-cache covers the full sequence (cached prefix + new tokens)
        kv_cache_bytes = model.get_kv_cache_size(seq_len=seq_len, batch_size=batch_size, precision=bpp)

        # 2. Disaggregated Serving (KV-Cache Transfer)
        # Splitwise/DistServe style: prefill and decode run on different nodes, so
        # the prompt's KV cache must cross the network before decoding can start.
        # That transfer lands on TTFT (the first token waits for it); decode then
        # reads from the decode node's own HBM.
        if decode_hardware:
            t_transfer = (kv_cache_bytes / network_bandwidth).to("ms")
            t_prefill += t_transfer
            decode_hw = decode_hardware
        else:
            decode_hw = hardware

        # 3. Decode Phase
        # Per decode step: load weights once (W) + load KV cache for all B requests.
        # kv_cache_bytes already includes batch_size from get_kv_cache_size().
        # Per-token ITL = step_time (each step produces 1 token per request).
        model_weights_bytes = model.size_in_bytes(bpp)
        step = _decode_step(
            model,
            decode_hw,
            batch_size=batch_size,
            context_tokens=seq_len,
            precision=precision,
            bytes_per_element=bpp,
            kv_bytes=kv_cache_bytes,
            efficiency=efficiency,
        )
        t_decode_per_token = step.latency
        draft_kv_cache = Q_("0 byte")

        # 5. Speculative Decoding
        # A small draft model proposes K tokens cheaply; the target model verifies
        # them in one parallel pass. The win comes from amortizing the target's
        # memory-bound weight load over several accepted tokens per step.
        if draft_model:
            # Time to generate 1 token with draft model (uses draft model's own KV cache, not target's)
            draft_kv_cache = draft_model.get_kv_cache_size(seq_len=seq_len, batch_size=batch_size, precision=bpp)
            t_draft_token = _decode_step(
                draft_model,
                decode_hw,
                batch_size=batch_size,
                context_tokens=seq_len,
                precision=precision,
                bytes_per_element=bpp,
                kv_bytes=draft_kv_cache,
                efficiency=efficiency,
            ).latency

            # Speculative decoding batches K draft tokens (e.g., K=4)
            K = cal.SPECULATIVE_GAMMA
            t_draft_phase = t_draft_token * K

            # Verification evaluates K proposed tokens and the bonus-token
            # distribution (Leviathan et al., Algorithm 1: p_1 ... p_(K+1)).
            # One weight read, but K+1 queries worth of compute work.
            t_verify = _decode_step(
                model,
                decode_hw,
                batch_size=batch_size,
                context_tokens=seq_len + K,
                precision=precision,
                bytes_per_element=bpp,
                kv_bytes=kv_cache_bytes,
                efficiency=efficiency,
                query_tokens=K + 1,
            ).latency

            # Expected tokens per step via geometric series (Leviathan et al., 2023):
            # E[accepted] = alpha*(1 - alpha^K)/(1 - alpha), plus 1 bonus token
            alpha = draft_acceptance_rate
            if alpha < 1.0:
                expected_tokens = 1 + alpha * (1 - alpha**K) / (1 - alpha)
            else:
                expected_tokens = 1 + K  # perfect acceptance

            # Effective ITL
            t_decode_per_token = (t_draft_phase + t_verify) / expected_tokens

        # Memory-wall feasibility on the decode node: weights + full-sequence KV
        # (+ draft weights and KV when speculating on the decode device).
        total_memory_required = model_weights_bytes + kv_cache_bytes
        if draft_model:
            total_memory_required += draft_model.size_in_bytes(bpp) + draft_kv_cache
        decode_feasible = total_memory_required <= decode_hw.memory.capacity
        prefill_memory_required = model_weights_bytes + kv_cache_bytes
        prefill_feasible = prefill_memory_required <= hardware.memory.capacity
        feasible = decode_feasible and prefill_feasible

        constraint_trace = [
            f"Decode roofline: {step.bottleneck}; compute={step.compute:~P}, "
            f"memory={step.memory:~P}, layer overhead={step.overhead:~P}. "
            "Terms describe the target step before speculative amortization.",
        ]
        if decode_hardware is not None:
            status = "Passed" if prefill_feasible else "FAILED"
            constraint_trace.append(
                f"Prefill Memory Wall: {status}. Required {prefill_memory_required.to('GB'):~P} "
                f"against capacity {hardware.memory.capacity.to('GB'):~P} on {hardware.name}; "
                "prefill offload is not modeled."
            )
        if draft_model is not None:
            constraint_trace.append(f"Draft KV cache included: {draft_kv_cache.to('GB'):~P}.")
        if decode_feasible:
            constraint_trace.append(
                f"Memory Wall: Passed. Required {total_memory_required.to('GB'):~P} (Weights: {model_weights_bytes.to('GB'):~P}, KV Cache: {kv_cache_bytes.to('GB'):~P}) <= Available {decode_hw.memory.capacity.to('GB'):~P} on {decode_hw.name}."
            )
        else:
            constraint_trace.append(
                f"Memory Wall: FAILED. Required {total_memory_required.to('GB'):~P} (Weights: {model_weights_bytes.to('GB'):~P}, KV Cache: {kv_cache_bytes.to('GB'):~P}) > Available {decode_hw.memory.capacity.to('GB'):~P} on {decode_hw.name}."
            )
        if prefill_chunk_tokens is not None and decode_stall_bound is not None:
            constraint_trace.append(
                f"Serving Wall: Chunked prefill uses {prefill_chunks} chunks of up to {prefill_chunk_tokens} tokens; "
                f"decode interference is bounded by {decode_stall_bound.to('ms'):~P} per prefill chunk."
            )

        cache_hit_ratio = cached_prefix_len / seq_len if seq_len > 0 else 0.0

        return ServingResult(
            feasible=feasible,
            constraint_trace=constraint_trace,
            ttft=t_prefill,
            itl=t_decode_per_token,
            kv_cache_size=kv_cache_bytes.to("GB"),
            model_weights_size=model_weights_bytes.to("GB"),
            total_memory_required=total_memory_required.to("GB"),
            memory_utilization=(total_memory_required / decode_hw.memory.capacity).to_base_units().magnitude,
            prompt_cache_hit_ratio=cache_hit_ratio,
            prefill_chunks=prefill_chunks,
            prefill_chunk_time=prefill_chunk_time,
            decode_stall_bound=decode_stall_bound,
        )


class ServingCapacityModel(ForwardModel):
    """
    Sizes an LLM serving deployment from a QPS and tail-latency target.

    The model deliberately composes existing first-order pieces: ``ServingModel``
    for TTFT/ITL, ``ContinuousBatchingModel`` for per-replica token capacity,
    and ``TailLatencyModel`` for queueing pressure. It is a capacity planner,
    not a request-level scheduler.
    """

    requires = ("workload", "hardware")
    produces = ServingCapacityResult

    def solve(
        self,
        model: TransformerWorkload,
        hardware: HardwareNode,
        qps: float,
        target_p99_latency_ms: float,
        max_seq_len: int = 2048,
        mean_request_tokens: Optional[float] = None,
        output_tokens: int = 128,
        max_batch_size: int = 32,
        precision: str = "fp16",
        efficiency: float = 0.5,
        max_replicas: int = 1024,
        service_time_cv: float = 1.0,
    ) -> ServingCapacityResult:
        """Return the minimum replica count that satisfies the target P99.

        Composes three first-order models and then scans replica counts
        upward (1, 2, ...) until the estimated request P99 meets the target:

        1. ``ContinuousBatchingModel`` sizes the per-replica active batch and
           token throughput under the memory wall, using paged allocation over
           the request-length distribution;
        2. ``ServingModel`` (at that batch and the mean request length) gives
           TTFT/ITL, so the base request latency is ``TTFT + ITL * output_tokens``;
        3. ``TailLatencyModel`` (M/M/c) adds the P99 queue wait at each
           candidate replica count.

        Estimated P99 = base request latency + P99 queue wait. Per-replica
        QPS capacity = token throughput / output_tokens.

        Parameters
        ----------
        model : TransformerWorkload
            The model being served.
        hardware : HardwareNode
            The per-replica accelerator.
        qps : float
            Target aggregate arrival rate in queries per second (> 0).
        target_p99_latency_ms : float
            End-to-end P99 latency target in milliseconds.
        max_seq_len : int
            Longest context a request may reach, prompt plus generated tokens.
        mean_request_tokens : float, optional
            Mean KV tokens a request fills, in ``(0, max_seq_len]``. ``None``
            means every request fills ``max_seq_len``. Shorter requests raise
            paged concurrency in ``ContinuousBatchingModel``.
        output_tokens : int
            Generated tokens per request; converts token throughput to QPS.
        max_batch_size : int
            Cap on concurrent requests per replica.
        precision : str
            Numerical precision for weights and KV cache.
        efficiency : float
            Software efficiency factor in (0, 1].
        max_replicas : int
            Search cap; reported as the requirement when infeasible.
        service_time_cv : float
            Coefficient of variation of service time (1.0 = M/M/c).

        Returns
        -------
        ServingCapacityResult
            Replica count, capacity/utilization, latency decomposition, and
            the limiting ``bottleneck`` ('Memory', 'Capacity', 'Tail Latency',
            'Base Latency', or 'Feasible').

        See Also
        --------
        ContinuousBatchingModel.solve : Paged per-replica token capacity.
        ServingModel.solve : Request prefill and decode time.
        TailLatencyModel.solve : Queue-wait approximation.

        Notes
        -----
        Equation: request_time = TTFT + ``output_tokens*ITL``; replica capacity
        is paged token throughput/output_tokens. Candidate P99 adds the queue
        wait to request_time and accepts the first replica count meeting the SLA.

        Assumptions: identical replicas, capped exponential request lengths,
        Poisson arrivals, and the service-variability approximation in TailLatencyModel.
        Mean request length sets fixed-context decode cost.
        Excludes: routing overhead, growing decode contexts, admission transients,
        and runtime workspace. Feasibility is conditional on these assumptions;
        reaching max_replicas without meeting the SLA returns feasible=False.

        References
        ----------
        Derivation: divide a token budget by tokens per request to obtain QPS,
        then compose independent request service and queue-wait estimates.

        Examples
        --------
        >>> from mlsysim import Hardware, Models
        >>> from mlsysim.solvers import ServingCapacityModel
        >>> r = ServingCapacityModel().solve(Models.Language.Llama3_8B, Hardware.Cloud.H100,
        ...     qps=1, target_p99_latency_ms=100000, max_replicas=2)
        >>> bool(r.feasible and r.required_replicas >= 1)
        True
        """
        from ...core._validation import validate_at_least, validate_nonnegative, validate_positive, validate_range

        validate_positive(qps, "qps")
        validate_positive(target_p99_latency_ms, "target_p99_latency_ms")
        validate_at_least(max_seq_len, 1, "max_seq_len")
        validate_at_least(output_tokens, 1, "output_tokens")
        validate_at_least(max_batch_size, 1, "max_batch_size")
        validate_at_least(max_replicas, 1, "max_replicas")
        validate_range(efficiency, 1e-9, 1.0, "efficiency")
        validate_nonnegative(service_time_cv, "service_time_cv")

        batching = ContinuousBatchingModel().solve(
            model=model,
            hardware=hardware,
            max_seq_len=max_seq_len,
            mean_request_tokens=mean_request_tokens,
            max_batch_size=max_batch_size,
            precision=precision,
            efficiency=efficiency,
        )
        active_batch = max(1, batching.max_active_requests)
        # Latency is evaluated at the mean request length. Flooring keeps the
        # ServingModel memory check inside the paged allocation that admitted
        # this batch, because the expected paged allocation per request is at
        # least the mean length.
        serving = ServingModel().solve(
            model=model,
            hardware=hardware,
            seq_len=max(1, int(batching.mean_request_tokens)),
            batch_size=active_batch,
            precision=precision,
            efficiency=efficiency,
        )
        # A request "costs" output_tokens decode steps, so replica QPS capacity is
        # token throughput spread over the per-request token budget.
        per_replica_qps = batching.throughput_tokens_per_sec / output_tokens if output_tokens > 0 else 0.0
        # Queue-free request latency: one prefill plus output_tokens decode steps.
        # Queue wait is layered on top of this per candidate replica count below.
        base_request_latency = (serving.ttft + serving.itl * output_tokens).to("ms")

        if not serving.feasible or not batching.feasible or per_replica_qps <= 0:
            bottleneck = "Memory" if not serving.feasible or not batching.feasible else "Capacity"
            return ServingCapacityResult(
                feasible=False,
                constraint_trace=[
                    "Serving Capacity: infeasible before queueing because the model does not fit or has no token capacity."
                ],
                required_replicas=max_replicas,
                qps_target=qps,
                qps_capacity=0.0,
                per_replica_qps_capacity=0.0,
                utilization=float("inf"),
                target_p99_latency=Q_(target_p99_latency_ms, "ms"),
                estimated_p99_latency=Q_(float("inf"), "ms"),
                base_request_latency=base_request_latency,
                queue_wait_p99=Q_(float("inf"), "ms"),
                active_batch_size=active_batch,
                ttft=serving.ttft,
                itl=serving.itl,
                bottleneck=bottleneck,
            )

        # The queueing model's "service time" is the replica's capacity interval
        # (1/QPS-capacity in ms): how long a replica is occupied per request from
        # the scheduler's point of view, not the request's wall-clock latency.
        capacity_service_ms = 1000.0 / per_replica_qps
        best_tail: Optional[TailLatencyResult] = None
        best_queue_wait = Q_(float("inf"), "ms")
        best_p99 = Q_(float("inf"), "ms")
        required_replicas = max_replicas
        feasible = False

        # Scan replica counts upward; queue wait shrinks monotonically with more
        # servers, so the first count that meets the target is the minimum.
        for replicas in range(1, max_replicas + 1):
            tail = TailLatencyModel().solve(
                arrival_rate_qps=qps,
                service_latency_ms=capacity_service_ms,
                num_replicas=replicas,
                service_time_cv=service_time_cv,
            )
            # TailLatencyModel folds the service time into its P99; strip it back
            # out to isolate pure queue wait, which we then add to the *request's*
            # real latency (TTFT + decode), a different quantity from the
            # capacity interval used inside the queueing model.
            queue_wait = max(0.0, tail.p99_latency.to("ms").magnitude - capacity_service_ms) * ureg.ms
            estimated_p99 = (base_request_latency + queue_wait).to("ms")
            best_tail = tail
            best_queue_wait = queue_wait
            best_p99 = estimated_p99
            if tail.is_stable and estimated_p99.magnitude <= target_p99_latency_ms:
                required_replicas = replicas
                feasible = True
                break

        qps_capacity = required_replicas * per_replica_qps
        utilization = qps / qps_capacity if qps_capacity > 0 else float("inf")
        # Name what binds: an unstable queue at max_replicas means raw capacity is
        # short; a stable queue that still misses P99 means tail latency binds; a
        # base latency already over target means no replica count can ever help
        # (the fix is a faster model/hardware, not more replicas).
        if not feasible:
            bottleneck = "Tail Latency" if best_tail and best_tail.is_stable else "Capacity"
        elif base_request_latency.magnitude > target_p99_latency_ms:
            bottleneck = "Base Latency"
        else:
            bottleneck = "Feasible"

        return ServingCapacityResult(
            feasible=feasible,
            constraint_trace=[
                (
                    f"Serving Capacity: {required_replicas} replicas provide {qps_capacity:.2f} QPS "
                    f"for target {qps:.2f} QPS at utilization {utilization:.2%}."
                ),
                (
                    f"Tail Latency: base request latency {base_request_latency:~P}; "
                    f"estimated P99 {best_p99:~P} vs target {Q_(target_p99_latency_ms, 'ms'):~P}."
                ),
            ],
            required_replicas=required_replicas,
            qps_target=qps,
            qps_capacity=qps_capacity,
            per_replica_qps_capacity=per_replica_qps,
            utilization=utilization,
            target_p99_latency=Q_(target_p99_latency_ms, "ms"),
            estimated_p99_latency=best_p99,
            base_request_latency=base_request_latency,
            queue_wait_p99=best_queue_wait,
            active_batch_size=active_batch,
            ttft=serving.ttft,
            itl=serving.itl,
            bottleneck=bottleneck,
        )


class ContinuousBatchingModel(ForwardModel):
    """
    Compares static KV reservation with PagedAttention under continuous batching.

    Decode is memory-bound, so the number of requests sharing a step is the
    throughput lever, and the KV-cache allocator decides how many fit. A static
    allocator reserves a contiguous slot of ``max_seq_len`` tokens for every
    request; PagedAttention hands out fixed-size blocks on demand. This model
    sizes both from the same KV budget and a request-length distribution, then
    compares memory-bound decode throughput at each allocator's concurrency.

    Kwon et al. (2023) profile contiguous pre-allocation (their Orca baselines)
    and find that only 20.4% to 38.2% of KV-cache memory holds actual token
    states (Fig. 2). The rest is reserved slots for future tokens, internal
    fragmentation from over-provisioning for the maximum sequence length, and
    external fragmentation from the memory allocator (Sec. 3.1, Fig. 3). vLLM
    limits each request's waste to one block (Sec. 4.2) and reaches 96.3%
    token-state usage (Fig. 2).

    Scope and assumptions:

    - The static baseline is max-length reservation, like Kwon's "Orca (Max)".
      It is modeled with no external fragmentation because every slot has the
      same size, although Kwon et al. still attribute 8.9% of Orca (Max) KV
      memory to external fragmentation and other overhead. Exact-size and
      power-of-two contiguous allocators, which trade reservation waste for
      external fragmentation, are not modeled.
    - Both allocators are sized with every admitted request at its full length
      (peak occupancy). A request mid-generation holds fewer paged blocks, so
      paged capacity is conservative, while static reserves ``max_seq_len``
      for the whole request lifetime either way.
    - Request lengths are exponential, cut off at ``max_seq_len``, with mean
      ``mean_request_tokens`` (``calc_capped_exponential_scale``).

    Literature Source:
    1. Kwon et al. (2023), "Efficient Memory Management for Large Language Model
       Serving with PagedAttention," SOSP '23.
    2. Yu et al. (2022), "ORCA: A Distributed Serving System for
       Transformer-Based Generative Models."
    """

    requires = ("workload", "hardware")
    produces = ContinuousBatchingResult

    def solve(
        self,
        model: TransformerWorkload,
        hardware: HardwareNode,
        max_seq_len: int,
        mean_request_tokens: Optional[float] = None,
        max_batch_size: int = 1,
        page_size: int = 16,
        precision: str = "fp16",
        efficiency: float = 0.5,
    ) -> ContinuousBatchingResult:
        """Compare static max-length KV reservation with paged allocation.

        With KV budget ``M_KV`` (HBM capacity minus weights) and ``k`` KV bytes
        per token:

        - **Static reservation**: every request reserves ``max_seq_len`` tokens,
          so ``N_static = floor(M_KV / (k * S_max))`` and the unused share of
          each reservation is ``1 - S_mean / S_max``.
        - **Paged allocation**: the budget is a pool of ``floor(M_KV / (k * p))``
          blocks and a request of ``S`` tokens holds ``ceil(S / p)`` of them, so
          ``N_paged = floor(pool / E[ceil(S / p)])``. The unused share is the
          expected tail of each request's last block
          (``calc_expected_paged_kv_tokens``), which grows with page size.
        - Both counts are capped by ``max_batch_size``. When the cap binds for
          both allocators, allocation policy cannot change throughput.
        - **Throughput**: each step streams weights plus filled KV tokens
          (reserved but empty slots are not read). Step latency is the larger
          of compute and memory time, plus the layer tax, using the same
          accounting as ServingModel. Tokens/s is ``N / t_step``; paging's
          throughput gain can saturate at the compute ceiling.
        - **TTFT** is the worst-case prefill of a full scheduler batch
          (``max_batch_size`` prompts of ``max_seq_len`` tokens): linear
          ``2*P*S`` plus attention ``4*L*H*d*S^2`` FLOPs, plus the dispatch tax.

        Parameters
        ----------
        model : TransformerWorkload
            The model being served (layers, heads, hidden_dim, kv_heads).
        hardware : HardwareNode
            The accelerator (HBM capacity/bandwidth, dispatch tax).
        max_seq_len : int
            Longest context a request may reach, prompt plus generated tokens.
            Static allocation reserves this much KV for every request.
        mean_request_tokens : float, optional
            Mean KV tokens a request actually fills, in ``(0, max_seq_len]``.
            Lengths are exponential, cut off at ``max_seq_len``, with this mean
            (``calc_capped_exponential_scale``). ``None`` means every request
            fills ``max_seq_len``; with no length variance, static and paged
            allocation coincide up to page rounding.
        max_batch_size : int
            Positive scheduler cap on concurrent requests.
        page_size : int
            Positive PagedAttention block size in tokens; default 16.
        precision : str
            Numerical precision for weights and KV cache.
        efficiency : float
            Software efficiency factor in (0, 1] applied to prefill and decode FLOPS.

        Returns
        -------
        ContinuousBatchingResult
            Paged and static concurrency and token throughput, internal
            fragmentation of each allocator (fractions), allocated KV, TTFT/ITL,
            and speedup vs static.

        See Also
        --------
        mlsysim.physics.memory.calc_expected_paged_kv_tokens : Page rounding.
        ServingModel.solve : Shared compute/memory decode accounting.

        Notes
        -----
        Equation: static concurrency is ``floor(KV_budget/(k*S_max))``; paged
        concurrency is floor(pool_blocks/E[blocks_per_request]). Both are
        capped by max_batch_size. Throughput = active_requests/decode_step_time.

        Assumptions: capped exponential request lengths, peak resident context
        per admitted request, fixed-size pages, peak memory bandwidth, and the
        shared decode Roofline including its layer tax.
        Excludes: external fragmentation, scheduler traces, arrival transients,
        workspace, tensor parallelism, and growing-context dynamics. Feasibility
        means modeled weights plus allocated KV fit, not engine deployability.

        References
        ----------
        Kwon et al. (2023), "Efficient Memory Management for Large Language
        Model Serving with PagedAttention."
        https://arxiv.org/abs/2309.06180 (bibliography key: kwon2023).
        The capped-exponential occupancy distribution is a modeling assumption,
        not a reproduction of vLLM scheduling.

        Examples
        --------
        >>> from mlsysim import Hardware, Models
        >>> from mlsysim.solvers import ContinuousBatchingModel
        >>> r = ContinuousBatchingModel().solve(Models.Language.Llama3_8B, Hardware.Cloud.H100,
        ...     max_seq_len=2048, mean_request_tokens=512, max_batch_size=8)
        >>> bool(r.feasible and r.max_active_requests <= 8 and r.throughput_tokens_per_sec > 0)
        True
        """
        from ...core._validation import validate_at_least, validate_range
        from ...physics import calc_expected_paged_kv_tokens

        validate_at_least(max_seq_len, 1, "max_seq_len")
        validate_at_least(max_batch_size, 1, "max_batch_size")
        validate_at_least(page_size, 1, "page_size")
        validate_range(efficiency, 1e-9, 1.0, "efficiency")
        if mean_request_tokens is None:
            mean_request_tokens = max_seq_len
        if not 0 < mean_request_tokens <= max_seq_len:
            raise ValueError(f"mean_request_tokens ({mean_request_tokens}) must be in (0, max_seq_len={max_seq_len}]")
        mean_request_tokens = float(mean_request_tokens)

        precision, bpp = resolve_precision(precision)
        peak_flops = hardware.compute.precision_flops.get(precision, hardware.compute.peak_flops)

        # Worst-case TTFT: a full scheduler batch of max-length prompts (linear
        # term plus the attention O(S²) term).
        n_layers = getattr(model, "layers", 1) or 1
        n_heads = getattr(model, "heads", 32) or 32
        head_dim = getattr(model, "head_dim", None) or (getattr(model, "hidden_dim", 4096) or 4096) // n_heads
        linear_flops = calc_transformer_decode_flops(model.parameters, max_seq_len) * max_batch_size
        attention_flops = calc_attention_matmul_flops(
            n_layers, n_heads * head_dim, max_seq_len, max_seq_len, max_batch_size
        )
        prefill_ops = linear_flops + attention_flops
        t_prefill = (prefill_ops / (peak_flops * efficiency)).to("ms") + hardware.dispatch_tax

        # KV budget is whatever HBM remains after the weights are pinned resident.
        model_weights_bytes = model.size_in_bytes(bpp)
        max_memory_for_kv = hardware.memory.capacity - model_weights_bytes

        if max_memory_for_kv.magnitude <= 0:
            return ContinuousBatchingResult(
                feasible=False,
                constraint_trace=[
                    f"Memory Wall: FAILED. Weights ({model_weights_bytes.to('GB'):~P}) exceed available {hardware.memory.capacity.to('GB'):~P} on {hardware.name}."
                ],
                throughput_tokens_per_sec=0.0,
                max_active_requests=0,
                static_throughput_tokens_per_sec=0.0,
                static_max_active_requests=0,
                mean_request_tokens=mean_request_tokens,
                paged_internal_fragmentation=0.0,
                static_internal_fragmentation=0.0,
                paged_kv_cache_size=Q_("0 GB"),
                static_kv_cache_size=Q_("0 GB"),
                ttft=t_prefill,
                itl=Q_("1000000 ms"),
                speedup_vs_static=1.0,
            )

        # KV bytes one token occupies (K and V across all layers, MLA-aware), and
        # the KV budget expressed in tokens.
        kv_bytes_per_token = model.get_kv_cache_size(seq_len=1, batch_size=1, precision=bpp)
        budget_tokens = (max_memory_for_kv / kv_bytes_per_token).to_base_units().magnitude

        # Static reservation: a contiguous max_seq_len slot per request, sized for
        # the worst case whatever the request actually uses. Floors are deliberate:
        # a partially fitting request cannot be admitted.
        static_capacity = int(budget_tokens // max_seq_len)
        static_requests = min(static_capacity, max_batch_size)
        static_frag = 1.0 - mean_request_tokens / max_seq_len

        # Paged allocation: a pool of fixed-size blocks, each request holding
        # ceil(S/p) blocks, averaged over the request-length distribution.
        paged_tokens_per_request, paged_frag = calc_expected_paged_kv_tokens(
            mean_request_tokens, max_seq_len, page_size_tokens=page_size
        )
        pool_blocks = int(budget_tokens // page_size)
        # The epsilon keeps an exact fit (fixed-length requests) from flooring one
        # request short on floating-point round-off.
        paged_capacity = int(math.floor(pool_blocks * page_size / paged_tokens_per_request + 1e-9))
        active_requests = min(paged_capacity, max_batch_size)

        def decode_step(n_requests: int) -> Quantity:
            # Reserved-but-empty KV slots are not read. Both allocators use
            # the same roofline and layer tax as ServingModel.
            filled_kv = kv_bytes_per_token * (n_requests * mean_request_tokens)
            return _decode_step(
                model,
                hardware,
                batch_size=n_requests,
                context_tokens=mean_request_tokens,
                precision=precision,
                bytes_per_element=bpp,
                kv_bytes=filled_kv,
                efficiency=efficiency,
            ).latency

        # One step emits one token per active request, so tokens/s is the batch
        # size over the step time.
        t_decode_per_token = decode_step(active_requests)
        throughput = (active_requests / t_decode_per_token).to("1/s").magnitude if active_requests > 0 else 0.0
        static_throughput = (
            (static_requests / decode_step(static_requests)).to("1/s").magnitude if static_requests > 0 else 0.0
        )
        if static_throughput > 0:
            speedup = throughput / static_throughput
        elif throughput > 0:
            # Paging admits requests that a max-length reservation cannot fit at all.
            speedup = float("inf")
        else:
            speedup = 1.0

        weights_gb = model_weights_bytes.to("GB")
        constraint_trace = []
        if active_requests > 0:
            constraint_trace.append(
                f"Memory Wall: Passed. Paged allocation fits {active_requests} concurrent requests (Weights: {weights_gb:~P}, Max KV available: {max_memory_for_kv.to('GB'):~P}) on {hardware.name}."
            )
        else:
            constraint_trace.append(
                f"Memory Wall: FAILED. Cannot fit even 1 request. Weights ({weights_gb:~P}) exceed or leave no room for KV cache in available {hardware.memory.capacity.to('GB'):~P} on {hardware.name}."
            )

        if mean_request_tokens >= max_seq_len:
            lengths = f"every request fills max_seq_len={max_seq_len}"
        else:
            lengths = f"mean {mean_request_tokens:,.0f} tokens, exponential up to max_seq_len={max_seq_len}"
        speedup_str = "unbounded (static fits no request)" if math.isinf(speedup) else f"{speedup:.2f}x"
        constraint_trace.append(
            f"Batching Wall: request lengths {lengths}. Static max-length reservation fits "
            f"{static_requests} requests ({static_frag:.1%} of each reservation unused); "
            f"{page_size}-token pages fit {active_requests} ({paged_frag:.1%} unused in last blocks); "
            f"decode throughput vs static {speedup_str} (Kwon et al., 2023)."
        )
        if 0 < active_requests == static_requests == max_batch_size:
            constraint_trace.append(
                f"Batching Wall: max_batch_size={max_batch_size} binds both allocators, "
                "so allocation policy does not change throughput."
            )

        return ContinuousBatchingResult(
            feasible=active_requests > 0,
            constraint_trace=constraint_trace,
            throughput_tokens_per_sec=throughput,
            max_active_requests=active_requests,
            static_throughput_tokens_per_sec=static_throughput,
            static_max_active_requests=static_requests,
            mean_request_tokens=mean_request_tokens,
            paged_internal_fragmentation=paged_frag,
            static_internal_fragmentation=static_frag,
            paged_kv_cache_size=(kv_bytes_per_token * (active_requests * paged_tokens_per_request)).to("GB"),
            static_kv_cache_size=(kv_bytes_per_token * (static_requests * max_seq_len)).to("GB"),
            ttft=t_prefill,
            itl=t_decode_per_token,
            speedup_vs_static=speedup,
        )


class WeightStreamingModel(ForwardModel):
    """
    Analyzes Wafer-Scale inference (e.g., Cerebras CS-3) using Weight Streaming.

    Instead of holding weights in HBM and streaming activations (the GPU Memory Wall),
    this architecture holds massive activation batches on-wafer (SRAM) and streams
    the model weights from external MemoryX nodes.

    The bottleneck shifts from Memory Bandwidth to Injection Interconnect Bandwidth.

    Literature Source:
    1. Lie et al. (2022), "Cerebras Architecture Deep Dive: First Look Inside
       the Hardware/Software Co-Design for Deep Learning."
    """

    requires = ("workload", "hardware")
    produces = WeightStreamingResult

    def solve(
        self,
        model: TransformerWorkload,
        hardware: HardwareNode,
        seq_len: int,
        batch_size: int = 1,
        precision: str = "fp16",
        efficiency: float = 0.5,
        phase: str = "decode",
    ) -> WeightStreamingResult:
        """Estimate layer-wise weight streaming time and on-device state capacity.

        Parameters
        ----------
        model : TransformerWorkload
            Transformer with positive layer count, parameters, and head geometry.
        hardware : HardwareNode
            Device supplying compute FLOP/s, resident memory bytes, dispatch time,
            and weight-injection interconnect bytes/s. Missing/zero injection
            bandwidth uses the fallback in engine.calibration.
        seq_len : int
            Positive resident context length in tokens per request.
        batch_size : int, optional
            Positive simultaneous requests; default one.
        precision : str, optional
            Weight and KV precision; default FP16.
        efficiency : float, optional
            Compute utilization in (0, 1]; default 0.5.
        phase : str, optional
            'prefill' processes seq_len tokens; 'decode' processes one token.
            Other strings currently follow the decode branch.

        Returns
        -------
        WeightStreamingResult
            Layer compute/injection times, throughput in tokens/s, memory
            utilization, optimal linear-work batch, and feasibility. Feasibility
            checks KV state plus the declared activation allowance only.

        Notes
        -----
        Equation: T_layer = max(W_layer/BW_inject, ``F_layer/(eta*peak)+dispatch)``.
        T_step = ``layers*T_layer``. Decode F_layer = ``2P_layer*B``. Prefill adds
        ``2*H_query*S^2*d*B`` to ``2P_layer*S*B`` under this model's approximation.
        Resident storage is 1.1 times KV bytes; the extra tenth is a declared
        activation allowance. Weights stream from external storage.

        Assumptions: uniform layers and complete injection/compute overlap.
        The optimal-batch estimate equates injection and linear compute time.
        Excludes: decode attention work, runtime workspace, detailed communication
        scheduling, and measured injection efficiency. Prefill uses the causal half-square attention approximation; ServingModel
        uses a rectangular upper bound over the final context.

        References
        ----------
        Derivation: divide each layer's weight bytes by injection bandwidth and
        its operation count by effective compute rate; the slower concurrent
        resource sets the layer time. The activation allowance is a heuristic.

        Examples
        --------
        >>> from mlsysim import Hardware, Models
        >>> from mlsysim.solvers import WeightStreamingModel
        >>> r = WeightStreamingModel().solve(Models.Language.Llama3_8B,
        ...     Hardware.Cloud.Cerebras_CS3, seq_len=128)
        >>> bool(r.feasible and r.layer_compute_time.m_as("ms") > 0)
        True
        """
        precision, bpp = resolve_precision(precision)
        peak_flops = hardware.compute.precision_flops.get(precision, hardware.compute.peak_flops)

        # 1. SRAM Capacity Constraint
        # Entire batch's KV Cache must fit in the 44GB on-wafer SRAM
        # Working set (activations for the current layer) must also fit, but KV cache dominates
        n_heads = model.kv_heads or model.heads or 32
        h_dim = model.hidden_dim or 4096
        head_dim = model.head_dim or h_dim // (model.heads or 32)

        # KV dimensions per layer per sequence; the factor 2 counts the separate
        # K and V tensors stored per attention head.
        total_kv_bytes = calc_kv_cache_size(model.layers, n_heads, head_dim, seq_len, batch_size, bpp)

        # 10% headroom for the current layer's activation working set — small next
        # to KV at these batch sizes, but not free.
        total_memory_required = (total_kv_bytes * 1.1).to("GB")

        feasible = total_memory_required <= hardware.memory.capacity
        # Convert to dimensionless before reading the magnitude: GB / GiB left
        # unreduced overstated utilization by 2^30 / 10^9 = 7.4% (fixed 2026-09-15).
        utilization = (
            (total_memory_required / hardware.memory.capacity).to("dimensionless").magnitude
            if hardware.memory.capacity.magnitude > 0
            else 1.0
        )

        constraint_trace = []
        if feasible:
            constraint_trace.append(
                f"SRAM Wall: Passed. Required {total_memory_required.to('GB'):~P} (KV + 10% Overhead) <= Available {hardware.memory.capacity.to('GB'):~P} on {hardware.name}."
            )
        else:
            constraint_trace.append(
                f"SRAM Wall: FAILED. Required {total_memory_required.to('GB'):~P} (KV + 10% Overhead) > Available {hardware.memory.capacity.to('GB'):~P} on {hardware.name}."
            )

        # 2. Injection Bottleneck vs Compute Bottleneck per Layer
        layer_params = model.parameters / model.layers
        layer_weight_bytes = layer_params.to(ureg.count).magnitude * bpp.magnitude * ureg.byte

        # Injection time (MemoryX -> WSE). Fall back to a calibrated default when
        # the registry entry is missing or zero — a zero injection bandwidth would
        # otherwise make the division below blow up.
        inj_bw = (
            hardware.interconnect.bandwidth
            if hardware.interconnect
            else Q_(cal.FALLBACK_INTERCONNECT_BANDWIDTH_GB_S, "GB/s")
        )
        if inj_bw.magnitude == 0:
            inj_bw = Q_(cal.FALLBACK_INTERCONNECT_BANDWIDTH_GB_S, "GB/s")

        layer_injection_time = (layer_weight_bytes / inj_bw).to("ms")

        # Compute time depends on phase
        if phase == "prefill":
            # Causal attention counts half the full square; query heads govern
            # compute even when GQA shares a smaller set of K/V heads.
            layer_linear_flops = calc_transformer_decode_flops(layer_params, seq_len) * batch_size
            layer_attention_flops = (
                calc_attention_matmul_flops(1, (model.heads or 32) * head_dim, seq_len, seq_len, batch_size) / 2
            )
            layer_decode_flops = layer_linear_flops + layer_attention_flops
        else:
            # This weight-streaming approximation excludes decode attention.
            layer_decode_flops = calc_transformer_decode_flops(layer_params) * batch_size
        layer_compute_time = (layer_decode_flops / (peak_flops * efficiency)).to("ms") + hardware.dispatch_tax

        # True layer time is bounded by the slowest process: weight streaming
        # overlaps injection with compute, so per-layer latency is max(), not sum.
        if layer_compute_time >= layer_injection_time:
            bottleneck = "Compute-Bound"
            layer_time = layer_compute_time
        else:
            bottleneck = "Interconnect-Bandwidth-Bound"
            layer_time = layer_injection_time

        total_token_time = layer_time * model.layers
        # In prefill, we process batch_size * seq_len tokens; in decode, batch_size tokens per step
        tokens_produced = batch_size * seq_len if phase == "prefill" else batch_size
        tps = (tokens_produced / total_token_time).to("1/s").magnitude if total_token_time.magnitude > 0 else 0.0

        # 3. Optimal Batch Size Analysis
        # What batch size perfectly overlaps injection and compute?
        # Solve: t_inject = (2 * layer_params * B) / (peak_flops * efficiency)
        # => B = t_inject * peak_flops * efficiency / (2 * layer_params)
        optimal_batch = (layer_injection_time * peak_flops * efficiency) / (
            2 * layer_params.to(ureg.count).magnitude * ureg.flop
        )
        optimal_batch_int = max(1, int(optimal_batch.to_base_units().magnitude))

        # Short-circuit: if infeasible (SRAM overflow), report zero throughput
        if not feasible:
            tps = 0.0

        return WeightStreamingResult(
            feasible=feasible,
            constraint_trace=constraint_trace,
            throughput_tokens_per_sec=tps,
            bottleneck=bottleneck,
            layer_compute_time=layer_compute_time,
            layer_injection_time=layer_injection_time,
            optimal_batch_size=optimal_batch_int,
            wafer_memory_utilization=min(utilization, 1.0) if feasible else utilization,
        )


class TailLatencyModel(ForwardModel):
    """
    Analyzes queueing delays and P99 tail latency for deployed inference models.

    Models inference servers as M/M/c queues to determine if the deployment
    can sustain the target arrival rate while meeting strict SLA latency bounds.

    Approximations (deliberate, pedagogical):
    - ``p50_latency``/``p99_latency`` add the WAIT-time quantile to the MEAN
      service time. The true quantile of sojourn time (wait + service) is
      generally larger, because service time has its own variance.
    - Kingman's ``(cv^2 + 1)/2`` factor is derived for the MEAN wait (M/G/1);
      applying it to the P50/P99 wait quantiles is a further heuristic.
    Quote these fields as model estimates, not exact M/G/c percentiles.

    Literature Source:
    1. Dean & Barroso (2013), "The Tail at Scale."
    """

    requires = ("hardware",)
    produces = TailLatencyResult

    def solve(
        self, arrival_rate_qps: float, service_latency_ms: float, num_replicas: int = 1, service_time_cv: float = 1.0
    ) -> TailLatencyResult:
        """Solve for P50 and P99 tail latencies under variable load.

        Parameters
        ----------
        arrival_rate_qps : float
            Request arrival rate in queries per second.
        service_latency_ms : float
            Mean service time per request in milliseconds.
        num_replicas : int
            Positive integer number of server replicas (c in M/M/c).
        service_time_cv : float
            Coefficient of variation of service time (default 1.0 = exponential).
            When CV != 1, applies Kingman's M/G/1 correction factor
            (cv^2 + 1) / 2 to queue wait times, approximating M/G/c behavior.

        Returns
        -------
        TailLatencyResult
            Estimated P50/P99 service-plus-wait times in milliseconds, utilization,
            stability, and a dimensionless ratio of P99 wait to five service times.
            Unstable queues have infinite waits; the ratio is not a probability.

        See Also
        --------
        mlsysim.physics.serving.calc_queue_latency_mmc : Erlang-C wait quantiles.

        Notes
        -----
        Equation: mu = 1000/service_latency_ms and rho = ``arrivals/(c*mu)``.
        Erlang-C wait quantiles are multiplied by (CV^2+1)/2, then the mean
        service duration is added to each quantile.

        Assumptions: nonnegative arrivals, positive mean service time, positive
        replica count, Poisson arrivals, and identical replicas. CV must be
        nonnegative; CV=1 gives the exponential-service queue approximation.
        Excludes: true convolution of service and wait distributions, bursty
        arrivals, heterogeneous servers, and scheduler dynamics. The CV correction
        is an approximation for multiple servers, not an exact M/G/c quantile.

        References
        ----------
        Derivation: compose the Erlang-C queue-wait quantile with a fixed mean
        service time. The variability multiplier extends a mean-wait correction
        to quantiles as a modeling approximation.

        Examples
        --------
        >>> from mlsysim.solvers import TailLatencyModel
        >>> r = TailLatencyModel().solve(arrival_rate_qps=1, service_latency_ms=10)
        >>> bool(r.is_stable and r.p99_latency >= r.p50_latency)
        True
        """
        from ...core._validation import validate_nonnegative

        validate_nonnegative(service_time_cv, "service_time_cv")
        from ...physics import calc_queue_latency_mmc

        # Queueing theory works in rates: mean service time (ms) -> per-server
        # service rate mu (requests/s).
        service_rate_hz = 1000.0 / service_latency_ms if service_latency_ms > 0 else 0.0

        rho, p50_w, p99_w = calc_queue_latency_mmc(arrival_rate_qps, service_rate_hz, num_replicas)

        # Kingman's formula correction for M/G/c approximation:
        # W_q(M/G/c) ≈ W_q(M/M/c) * (cv² + 1) / 2
        # When cv=1 (exponential), the factor is 1.0 (no correction).
        if service_time_cv != 1.0:
            kingman_factor = (service_time_cv**2 + 1) / 2
            p50_w = p50_w * kingman_factor
            p99_w = p99_w * kingman_factor

        is_stable = rho < 1.0

        # P99 wait time exceeding 5x service latency signifies severe SLA risk
        slo_threshold = service_latency_ms * 5

        p99_w_ms = p99_w.m_as(ureg.millisecond)
        p50_w_ms = p50_w.m_as(ureg.millisecond)

        # SLO headroom: ratio of P99 wait to SLO threshold.
        # Values > 1.0 indicate SLO violation. This is a ratio, not a probability.
        slo_headroom_ratio = 1.0 if not is_stable else (p99_w_ms / slo_threshold if slo_threshold > 0 else 0)
        slo_headroom_ratio = max(0.0, slo_headroom_ratio)  # No upper clamp: values > 1.0 indicate SLO violation

        return TailLatencyResult(
            p50_latency=Q_(p50_w_ms + service_latency_ms, "ms"),
            p99_latency=Q_(p99_w_ms + service_latency_ms, "ms"),
            queue_utilization=rho,
            is_stable=is_stable,
            slo_headroom_ratio=slo_headroom_ratio,
        )


class InferenceScalingModel(ForwardModel):
    """
    Models inference-time compute scaling (Wall 12: Reasoning/CoT Cost).

    This model quantifies the cost of 'System-2 thinking' — inference-time
    compute scaling via chain-of-thought (CoT) reasoning, where the model
    generates K intermediate reasoning steps before producing the final answer.
    Each step incurs the full cost of autoregressive decoding.

    Literature Source:
    1. Wei et al. (2022), "Chain-of-Thought Prompting Elicits Reasoning in
       Large Language Models."
    2. Snell et al. (2024), "Scaling LLM Test-Time Compute Optimally Can Be
       More Effective Than Scaling Model Parameters."
    3. OpenAI (2024), "Learning to Reason with LLMs." (o1 reasoning model.)
    """

    requires = ("workload", "hardware")
    produces = InferenceScalingResult

    def solve(
        self,
        model: TransformerWorkload,
        hardware: HardwareNode,
        reasoning_steps: int = 8,
        context_length: int = 2048,
        precision: str = "fp16",
        efficiency: float = 0.5,
    ) -> InferenceScalingResult:
        """Solve for inference-time reasoning cost.

        Parameters
        ----------
        model : TransformerWorkload
            The language model used for reasoning.
        hardware : HardwareNode
            The target hardware node.
        reasoning_steps : int
            Nonnegative reasoning-step count K; each uses the declared token budget.
        context_length : int
            Positive fixed input context length in tokens.
        precision : str
            Weight and KV element precision, such as fp16 or int8.
        efficiency : float
            Compute efficiency fraction in (0, 1]; default 0.5.

        Returns
        -------
        InferenceScalingResult
            Total reasoning time, TDP-based energy per query in joules, and token counts.

        See Also
        --------
        ServingModel.solve : Prefill, decode, and memory feasibility.

        Notes
        -----
        Equation: generated_tokens = ``K*N_step``; T = TTFT + ``K*N_step*ITL``;
        energy = ``TDP*T`` when TDP is available, otherwise zero is returned.
        N_step is the declared TOKENS_PER_REASONING_STEP calibration default.

        Assumptions: nonnegative reasoning-step count, fixed context for every
        decode step, and the batch-one ServingModel assumptions.
        Excludes: reasoning-quality prediction, growing contexts, verification
        work, measured power, and price. Feasibility is inherited from serving;
        a computed duration for an infeasible configuration is not deployable.

        References
        ----------
        Derivation: multiply a supplied step count by an assumed token budget
        and per-token latency, then add one prefill. Energy uses a TDP-time proxy;
        neither token budget nor power is a measured workload trace.

        Examples
        --------
        >>> from mlsysim import Hardware, Models
        >>> from mlsysim.solvers import InferenceScalingModel
        >>> solver = InferenceScalingModel()
        >>> a = solver.solve(Models.Language.Llama3_8B, Hardware.Cloud.H100, reasoning_steps=1)
        >>> b = solver.solve(Models.Language.Llama3_8B, Hardware.Cloud.H100, reasoning_steps=2)
        >>> bool(b.tokens_generated == 2*a.tokens_generated and b.total_reasoning_time > a.total_reasoning_time)
        True
        """
        # Use ServingModel internally to get per-step latency
        serving = ServingModel()
        serving_result = serving.solve(
            model=model,
            hardware=hardware,
            seq_len=context_length,
            batch_size=1,
            precision=precision,
            efficiency=efficiency,
        )

        # Inter-token latency (ITL) is the cost per generated token
        itl = serving_result.itl

        # Average tokens per reasoning step (heuristic — see core/calibration.py)
        tokens_per_step = cal.TOKENS_PER_REASONING_STEP
        total_tokens = reasoning_steps * tokens_per_step

        # T_reason = K × tokens_per_step × ITL + TTFT (initial prefill)
        ttft = serving_result.ttft
        t_step = tokens_per_step * itl
        total_reasoning_time = ttft + reasoning_steps * t_step

        # Cost estimate (based on hardware TDP and time)
        if hardware.tdp is not None:
            energy_j = (hardware.tdp * total_reasoning_time.to("s")).to("J")
        else:
            energy_j = Q_("0 J")

        return InferenceScalingResult(
            total_reasoning_time=total_reasoning_time.to("ms"),
            ttft=ttft,
            itl=itl,
            tokens_generated=total_tokens,
            reasoning_steps=reasoning_steps,
            time_per_step=t_step.to("ms"),
            energy_per_query=energy_j,
            feasible=serving_result.feasible,
            serving_detail=serving_result,
        )


class BatchingOptimizer(BaseOptimizer):
    """
    Finds the maximum batch size that satisfies a P99 latency SLA.

    Searches the continuous batching design space using an M/M/c queueing
    model to find the optimal balance between throughput and tail latency.
    """

    requires = ("workload", "hardware", "sla_latency_ms")
    produces = BatchingOptimizerResult

    def solve(
        self,
        model: TransformerWorkload,
        hardware: HardwareNode,
        seq_len: int,
        sla_latency_ms: float,
        arrival_rate_qps: float,
        num_replicas: int = 1,
        precision: str = "fp16",
        efficiency: float = 0.5,
        max_search_batch: int = 256,
    ) -> BatchingOptimizerResult:
        """Determine the maximum batch size that satisfies a P99 latency SLA.

        Exhaustively scans batch sizes 1..``max_search_batch``. For each
        candidate ``b``, the per-batch service latency is
        ``TTFT + ITL * seq_len`` from ``ServingModel``, and the batch arrival
        rate is ``arrival_rate_qps / b`` (requests are grouped into batches).
        A candidate is feasible when the model fits in memory, the M/M/c
        queue is stable, and the queueing P99 meets the SLA. Among feasible
        candidates the largest batch wins by the chosen objective; this is not
        a separate optimization of saturation throughput.

        Parameters
        ----------
        model : TransformerWorkload
            The model being served.
        hardware : HardwareNode
            The serving accelerator.
        seq_len : int
            Tokens generated per request (used as the decode count).
        sla_latency_ms : float
            P99 latency SLA in milliseconds.
        arrival_rate_qps : float
            Aggregate request arrival rate in queries per second.
        num_replicas : int
            Number of serving replicas (the 'c' in M/M/c).
        precision : str
            Weight and KV element precision, such as fp16 or int8.
        efficiency : float
            Software efficiency factor in (0, 1].
        max_search_batch : int
            Upper bound of the batch-size search range.

        Returns
        -------
        BatchingOptimizerResult
            Best batch size, resulting throughput (tokens/s), P99 latency,
            and SLO headroom; ``is_feasible=False`` if no batch size works.

        See Also
        --------
        ServingModel.solve : Candidate service and capacity calculation.
        TailLatencyModel.solve : Queueing estimate for grouped arrivals.

        Notes
        -----
        Equation: service_time(b) = TTFT(b) + ``seq_len*ITL(b)``, with batch
        arrival rate qps/b. Search maximizes b among memory-feasible, stable
        candidates whose estimated P99 is within sla_latency_ms.

        Assumptions: positive SLA, arrival rate, sequence length, replica count,
        and search cap; fixed context and grouped arrivals. seq_len is used as
        both prompt/context length and generated token count in this scenario.
        Excludes: time spent forming batches, growing KV contexts, and dynamic
        scheduling. Returned max_throughput is offered ``qps*seq_len``, not a measured
        or independently optimized saturation capacity. No feasible candidate
        returns is_feasible=False and batch zero.

        References
        ----------
        Derivation: enumerate the integer batch domain, apply modeled capacity
        and latency constraints, and choose the largest admitted batch.

        Examples
        --------
        >>> from mlsysim import Hardware, Models
        >>> from mlsysim.solvers import BatchingOptimizer
        >>> r = BatchingOptimizer().solve(Models.Language.Llama3_8B, Hardware.Cloud.H100,
        ...     seq_len=8, sla_latency_ms=10000, arrival_rate_qps=1, max_search_batch=2)
        >>> bool(r.is_feasible and 1 <= r.best_batch_size <= 2)
        True
        """
        from ...core.optimization.registry import OptimizationRegistry

        serving_model = ServingModel()
        tail_model = TailLatencyModel()

        def objective(b_array):
            """Prefer the largest feasible batch.

            Return -b for feasible batches and a penalty for memory-infeasible,
            unstable, or SLA-violating ones.
            """
            b = int(b_array[0])
            res = serving_model.solve(
                model, hardware, seq_len=seq_len, batch_size=b, precision=precision, efficiency=efficiency
            )
            if not res.feasible:
                return 1e12  # Infeasible due to memory

            service_latency = res.ttft + (res.itl * seq_len)
            # Requests are grouped b-at-a-time, so the queue sees batches arriving
            # at qps/b — larger batches mean fewer, slower queue customers.
            tail_res = tail_model.solve(arrival_rate_qps / b, service_latency.m_as("ms"), num_replicas)

            if not tail_res.is_stable or tail_res.p99_latency.m_as("ms") > sla_latency_ms:
                return 1e12  # Infeasible due to queueing instability or SLA violation

            # We want to maximize batch size (which maximizes valid throughput), so minimize -b
            return -b

        backend = OptimizationRegistry.get_backend("exhaustive")
        backend.compile(objective_fn=objective, ranges=[(1, max_search_batch)], grid_size=max_search_batch)
        opt_res = backend.solve()

        if not opt_res.feasible:
            return BatchingOptimizerResult(
                objective_value=0.0,
                best_config={"max_batch_size": 0},
                best_batch_size=0,
                max_throughput=0.0,
                p99_latency=Q_("0 ms"),
                slo_headroom_ratio=0.0,
                is_feasible=False,
                total_searched=max_search_batch,
            )

        best_b = int(opt_res.best_configuration["optimal_variable"])
        max_tps = arrival_rate_qps * seq_len

        # Resolve final exact metrics for the optimal batch size
        res = serving_model.solve(
            model, hardware, seq_len=seq_len, batch_size=best_b, precision=precision, efficiency=efficiency
        )
        service_latency = res.ttft + (res.itl * seq_len)
        tail_res = tail_model.solve(arrival_rate_qps / best_b, service_latency.m_as("ms"), num_replicas)

        return BatchingOptimizerResult(
            objective_value=max_tps,
            best_config={"max_batch_size": best_b},
            best_batch_size=best_b,
            max_throughput=max_tps,
            p99_latency=tail_res.p99_latency,
            slo_headroom_ratio=tail_res.slo_headroom_ratio,
            is_feasible=True,
            total_searched=max_search_batch,
        )


__all__ = [
    "ServingModel",
    "ServingCapacityModel",
    "ContinuousBatchingModel",
    "WeightStreamingModel",
    "TailLatencyModel",
    "InferenceScalingModel",
    "BatchingOptimizer",
]
