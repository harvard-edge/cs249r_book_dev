# viz/plots.py
# Simulator-aware plotters for generated MLSysIM figures.
# Book publication style is owned by book.tools.figures.style; this module keeps
# a local fallback so standalone mlsysim installs do not depend on the book tree.

import os

try:
    import numpy as np
except ImportError:
    np = None

try:
    from binder.tools.figures.style import (
        COLORS,
        WEB_FIG_DPI,
        bar_compare,
        finalize_web_figure as _finalize_web_figure,
        set_book_style,
        setup_plot,
    )
except ImportError:
    # Standalone mlsysim fallback. Keep in sync with book.tools.figures.style.
    try:
        import matplotlib

        if "MPLBACKEND" not in os.environ:
            matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as plt

        _matplotlib_available = True
    except ImportError:
        plt = None
        _matplotlib_available = False

    COLORS = {
        "crimson": "#A51C30",
        "primary": "#333333",
        "grid": "#CCCCCC",
        "BlueLine": "#006395",
        "BlueL": "#D1E6F3",
        "BlueFill": "#D6EAF8",
        "RedLine": "#CB202D",
        "RedL": "#F5D2D5",
        "RedFill": "#F2D7D5",
        "GreenLine": "#008F45",
        "GreenL": "#D4EFDF",
        "GreenFill": "#D5F5E3",
        "OrangeLine": "#E67817",
        "OrangeL": "#FCE4CC",
        "VioletLine": "#7E317B",
        "VioletL": "#E6D4E5",
        "BrownLine": "#78492A",
        "BrownL": "#E3D3C8",
        "YellowFill": "#FEF9E0",
    }

    WEB_FIG_DPI = 120

    def set_book_style():
        """Apply the global matplotlib style configuration."""
        if not _matplotlib_available:
            raise ImportError("matplotlib is required for plot generation.")
        plt.rcParams.update(
            {
                "font.family": "sans-serif",
                "font.sans-serif": [
                    "Helvetica",
                    "Helvetica Neue",
                    "Arial",
                    "DejaVu Sans",
                ],
                "font.size": 10,
                "text.color": COLORS["primary"],
                "axes.labelsize": 11,
                "axes.titlesize": 12,
                "axes.titleweight": "bold",
                "axes.grid": True,
                "grid.color": COLORS["grid"],
                "grid.alpha": 0.4,
                "grid.linestyle": "--",
                "figure.dpi": 300,
                "savefig.bbox": "tight",
            }
        )

    def _finalize_web_figure(fig):
        """Match Quarto web defaults while publication figures keep print DPI."""
        fig.set_dpi(WEB_FIG_DPI)
        return fig

    def setup_plot(figsize=(8, 5)):
        """One-line plot setup for generated plotting blocks."""
        set_book_style()
        fig, ax = plt.subplots(figsize=figsize)
        return fig, ax, COLORS, plt

    def bar_compare(labels, values, *, title=None, ylabel=None, figsize=(8, 4), color=None):
        """Render a compact bar comparison with the MLSysBook style."""
        fig, ax, colors, _ = setup_plot(figsize=figsize)
        bar_color = color or colors["BlueLine"]
        bars = ax.bar(labels, values, color=bar_color, alpha=0.8)
        if title:
            ax.set_title(title)
        if ylabel:
            ax.set_ylabel(ylabel)
        ax.tick_params(axis="x", rotation=0)
        for bar, value in zip(bars, values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height(),
                f"{value:g}",
                ha="center",
                va="bottom",
                fontsize=9,
                color=colors["primary"],
            )
        return _finalize_web_figure(fig), ax


def plot_roofline(hardware_node, workloads=None, title=None):
    """
    Plots a publication-quality Roofline Model for a given HardwareNode.

    Features:
    - Ridge point annotated with numeric value
    - Memory-bound and compute-bound regions shaded and labeled
    - Memory bandwidth ceiling (diagonal) and compute ceiling (flat)
    - Workloads plotted with bottleneck classification
    """
    # 1. PARAMETERS
    peak_flops = hardware_node.compute.peak_flops.to("TFLOPs/s").magnitude
    peak_bw = hardware_node.memory.bandwidth.to("GB/s").magnitude
    ridge_point = peak_flops / (peak_bw / 1000)  # FLOP/Byte

    # 2. AXIS RANGE
    x_min, x_max = 0.1, 10000
    x = np.logspace(np.log10(x_min), np.log10(x_max), 500)

    # 3. ROOFLINE CURVES
    y_mem = peak_bw * x / 1000  # BW * AI, converted to TFLOP/s
    y_compute = np.full_like(x, peak_flops)
    y_roof = np.minimum(y_mem, y_compute)

    # 4. PLOT
    fig, ax, colors, _ = setup_plot(figsize=(9, 5.5))

    # Shaded regions
    mem_mask = x <= ridge_point
    comp_mask = x >= ridge_point
    ax.fill_between(
        x[mem_mask],
        y_roof[mem_mask] * 0.001,
        y_roof[mem_mask],
        color=colors["BlueL"],
        alpha=0.5,
        label="Memory-bound region",
    )
    ax.fill_between(
        x[comp_mask],
        y_roof[comp_mask] * 0.001,
        y_roof[comp_mask],
        color=colors["OrangeL"],
        alpha=0.5,
        label="Compute-bound region",
    )

    # Roofline line
    ax.loglog(
        x[mem_mask],
        y_roof[mem_mask],
        color=colors["BlueLine"],
        linewidth=2.5,
        zorder=5,
    )
    ax.loglog(
        x[comp_mask],
        y_roof[comp_mask],
        color=colors["OrangeLine"],
        linewidth=2.5,
        zorder=5,
    )

    # Memory bandwidth ceiling label (on the slope)
    slope_x = ridge_point * 0.08
    slope_y = peak_bw * slope_x / 1000
    ax.text(
        slope_x,
        slope_y * 1.6,
        f"BW ceiling: {peak_bw:.0f} GB/s",
        color=colors["BlueLine"],
        fontsize=8.5,
        fontweight="bold",
        rotation=38,
        ha="center",
        va="bottom",
    )

    # Compute ceiling label (on the flat)
    ax.text(
        ridge_point * 8,
        peak_flops * 1.12,
        f"Compute ceiling: {peak_flops:.0f} TFLOP/s",
        color=colors["OrangeLine"],
        fontsize=8.5,
        fontweight="bold",
        ha="center",
        va="bottom",
    )

    # Ridge point
    ax.plot(
        ridge_point,
        peak_flops,
        "D",
        color=colors["crimson"],
        markersize=9,
        zorder=10,
    )
    ax.annotate(
        f"Ridge Point\n{ridge_point:.1f} FLOP/Byte",
        xy=(ridge_point, peak_flops),
        xytext=(ridge_point * 2.6, peak_flops * 0.26),
        fontsize=8.5,
        fontweight="bold",
        color=colors["crimson"],
        ha="center",
        arrowprops=dict(
            arrowstyle="->",
            color=colors["crimson"],
            lw=1.2,
        ),
    )

    # Vertical dashed line at ridge point
    ax.axvline(
        ridge_point,
        color=colors["crimson"],
        linestyle=":",
        linewidth=0.8,
        alpha=0.5,
    )

    # Region labels
    ax.text(
        (x_min * ridge_point) ** 0.5,
        peak_flops * 0.02,
        "MEMORY\nBOUND",
        color=colors["BlueLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="left",
        va="center",
    )
    ax.text(
        (ridge_point * x_max) ** 0.5,
        peak_flops * 0.02,
        "COMPUTE\nBOUND",
        color=colors["OrangeLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="center",
        va="center",
    )

    # Plot workloads
    if workloads:
        from ..engine.solvers import SingleNodeModel

        workload_colors = [
            colors["primary"],
            colors["GreenLine"],
            colors["VioletLine"],
            colors["BrownLine"],
        ]
        for i, model in enumerate(workloads):
            profile = SingleNodeModel().solve(model, hardware_node, efficiency=1.0)
            ai = profile.arithmetic_intensity.magnitude
            perf = min(peak_bw * ai / 1000, peak_flops)
            c = workload_colors[i % len(workload_colors)]
            bound = "memory" if ai < ridge_point else "compute"
            ax.plot(ai, perf, "o", color=c, markersize=9, zorder=10)
            ax.annotate(
                f"{model.name}\n({bound}-bound)",
                xy=(ai, perf),
                xytext=(ai * 0.3, perf * 0.4),
                fontsize=8,
                fontweight="bold",
                color=c,
                ha="center",
                arrowprops=dict(arrowstyle="->", color=c, lw=1),
            )

    ax.set_xlabel("Arithmetic Intensity (FLOP/Byte)")
    ax.set_ylabel("Performance (TFLOP/s)")
    # The document caption owns the figure title; pass `title` only for
    # standalone use outside the book.
    if title:
        ax.set_title(title)
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(peak_flops * 0.001, peak_flops * 2)
    ax.legend(loc="lower right", fontsize=8, framealpha=0.9)
    return _finalize_web_figure(fig), ax

def plot_distributed_roofline(fleet_system, workloads=None):
    """
    Plots a Distributed (Network) Roofline Model for a given fleet.
    Maps Performance (TFLOP/s) against Communication Intensity (FLOP/Byte).
    
    Timeless Principle: The Network Wall is hit when gradient/activation
    synchronization exceeds the fleet's bisection bandwidth.
    """
    # 1. PARAMETERS (Fleet Specs)
    peak_flops = fleet_system.node.accelerator.compute.peak_flops.to("TFLOPs/s").magnitude * fleet_system.count
    # Bisection Bandwidth (total network capacity for All-Reduce)
    peak_network_bw = fleet_system.fabric.bandwidth.to("GB/s").magnitude
    ridge_point = peak_flops / (peak_network_bw / 1000) # FLOP/Byte

    # 2. AXIS RANGE
    x_min, x_max = 0.1, 10000
    x = np.logspace(np.log10(x_min), np.log10(x_max), 500)

    # 3. ROOFLINE CURVES
    y_net = peak_network_bw * x / 1000  # Network BW * CI, converted to TFLOP/s
    y_compute = np.full_like(x, peak_flops)
    y_roof = np.minimum(y_net, y_compute)

    # 4. PLOT
    fig, ax, colors, _ = setup_plot(figsize=(9, 5.5))

    # Shaded regions
    net_mask = x <= ridge_point
    comp_mask = x >= ridge_point
    ax.fill_between(
        x[net_mask],
        y_roof[net_mask] * 0.001,
        y_roof[net_mask],
        color=colors["RedL"],
        alpha=0.5,
        label="Network-bound region",
    )
    ax.fill_between(
        x[comp_mask],
        y_roof[comp_mask] * 0.001,
        y_roof[comp_mask],
        color=colors["BlueFill"],
        alpha=0.5,
        label="Compute-bound region",
    )

    # Roofline line
    ax.loglog(
        x,
        y_roof,
        color=colors["VioletLine"],
        linewidth=2.5,
        zorder=5,
    )

    # Network bandwidth ceiling label
    slope_x = ridge_point * 0.08
    slope_y = peak_network_bw * slope_x / 1000
    ax.text(
        slope_x,
        slope_y * 1.6,
        f"Bisection BW: {peak_network_bw:.0f} GB/s",
        color=colors["RedLine"],
        fontsize=8.5,
        fontweight="bold",
        rotation=38,
        ha="center",
        va="bottom",
    )

    # Fleet Compute ceiling label
    ax.text(
        ridge_point * 8,
        peak_flops * 1.12,
        f"Fleet Compute: {peak_flops:.0f} TFLOP/s",
        color=colors["BlueLine"],
        fontsize=8.5,
        fontweight="bold",
        ha="center",
        va="bottom",
    )

    # Ridge point
    ax.plot(
        ridge_point,
        peak_flops,
        "X",
        color=colors["crimson"],
        markersize=10,
        zorder=10,
    )
    ax.annotate(
        f"Network Ridge\n{ridge_point:.1f} FLOP/Byte",
        xy=(ridge_point, peak_flops),
        xytext=(ridge_point * 2, peak_flops * 0.25),
        fontsize=8.5,
        fontweight="bold",
        color=colors["crimson"],
        ha="center",
        arrowprops=dict(arrowstyle="->", color=colors["crimson"], lw=1.2),
    )

    # Region labels
    ax.text(
        x_min * 1.5,
        peak_flops * 0.6,
        "NETWORK\nBOUND",
        color=colors["RedLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="left",
        va="center",
    )
    ax.text(
        x_max * 0.4,
        peak_flops * 0.6,
        "COMPUTE\nBOUND",
        color=colors["BlueLine"],
        fontsize=11,
        fontweight="bold",
        alpha=0.25,
        ha="right",
        va="center",
    )

    ax.set_xlabel("Communication Intensity (FLOP/Byte)")
    ax.set_ylabel("Fleet Performance (TFLOP/s)")
    ax.set_title(f"Distributed Roofline: {fleet_system.count}x {fleet_system.node.accelerator.name}")
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(peak_flops * 0.001, peak_flops * 2)
    ax.legend(loc="lower right", fontsize=8, framealpha=0.9)
    return _finalize_web_figure(fig), ax

def _metric_as_float(value, unit=None):
    """Return a numeric metric, converting Pint quantities when needed."""
    if hasattr(value, "m_as") and unit is not None:
        return float(value.m_as(unit))
    if hasattr(value, "to") and unit is not None:
        return float(value.to(unit).magnitude)
    if hasattr(value, "magnitude"):
        return float(value.magnitude)
    return float(value)

def _metric_ratio(numerator, denominator):
    """Return numerator / denominator for scalar or Pint quantity metrics."""
    if hasattr(numerator, "to") and hasattr(denominator, "units"):
        return float((numerator / denominator).to_base_units().magnitude)
    return float(numerator) / float(denominator)

def _memory_utilization(metrics):
    """Read or derive memory utilization from an evaluation metrics payload."""
    if "memory_utilization" in metrics:
        return float(metrics["memory_utilization"])
    if "weight_size" in metrics and "capacity" in metrics:
        return _metric_ratio(metrics["weight_size"], metrics["capacity"])
    if "memory_used_gb" in metrics and "memory_capacity_gb" in metrics:
        return _metric_ratio(metrics["memory_used_gb"], metrics["memory_capacity_gb"])
    return 0.0

def plot_evaluation_scorecard(evaluation):
    """
    Visualizes the supply-vs-demand scorecard for a SystemEvaluation.
    Follows the compact, labeled visualization pattern used by generated examples.
    """
    l1_metrics = evaluation.feasibility.metrics
    l2_metrics = evaluation.performance.metrics
    
    # 2. CALCULATION
    l1_ratio = _memory_utilization(l1_metrics)
    latency_ms = _metric_as_float(l2_metrics.get("latency", 0.0), "ms")
    sla_ms = _metric_as_float(
        l2_metrics.get("sla_latency_ms", l2_metrics.get("sla_latency", 1000.0)),
        "ms",
    )
    l2_ratio = latency_ms / sla_ms if sla_ms > 0 else 0.0
    
    levels = ['Memory (RAM)', 'Latency (SLA)']
    ratios = [l1_ratio, l2_ratio]
    
    # 3. OUTPUT (Visualization)
    fig, ax, colors, plt = setup_plot(figsize=(8, 4))
    bar_colors = [colors['RedLine'] if r > 1.0 else colors['GreenLine'] for r in ratios]
    bars = ax.barh(levels, ratios, color=bar_colors, alpha=0.7, edgecolor='black')
    
    ax.axvline(1.0, color=colors['primary'], linestyle='--', linewidth=2, label='Physical Limit / SLA')
    
    for i, (bar, ratio) in enumerate(zip(bars, ratios)):
        ax.text(bar.get_width() + 0.05, bar.get_y() + bar.get_height()/2, f"{ratio:.1%}", 
                va='center', fontweight='bold', color=bar_colors[i])

    ax.set_xlim(0, max(max(ratios) + 0.5, 1.5))
    ax.set_xlabel('Resource Utilization (Demand / Supply)')
    ax.set_title(f'System Evaluation: {evaluation.scenario_name}')
    return _finalize_web_figure(fig), ax
