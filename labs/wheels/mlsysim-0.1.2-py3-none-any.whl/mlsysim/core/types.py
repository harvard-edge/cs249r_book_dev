from typing import Any, Annotated, Optional
from pydantic import AfterValidator, PlainSerializer, BaseModel
from .constants import Q_
from .provenance import Provenance

def validate_quantity(v: Any) -> Q_:
    if isinstance(v, Q_):
        return v
    if isinstance(v, (int, float, str)):
        try:
            return Q_(v)
        except Exception as e:
            raise ValueError(f"Could not parse Quantity from {v}: {e}")
    raise ValueError(f"Expected Quantity, got {type(v)}")

def serialize_quantity(v: Q_) -> str:
    # Use compact format for serialization
    return f"{v:~P}"

Quantity = Annotated[
    Any,
    AfterValidator(validate_quantity),
    PlainSerializer(serialize_quantity, return_type=str)
]

class Metadata(BaseModel):
    """Provenance for registry entries (hardware, models, fabrics)."""

    provenance: Optional[Provenance] = None
    description: Optional[str] = None
    last_verified: Optional[str] = None  # YYYY-MM-DD
    version: Optional[str] = None

    @property
    def source_label(self) -> Optional[str]:
        """Human-readable source label from provenance."""
        if self.provenance is not None:
            return self.provenance.ref
        return None
