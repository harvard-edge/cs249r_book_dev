"""Published measurement series (multi-row, multi-field) cited by the books.

The scalar-anchor YAML schema in ``literature/data/*.yaml`` cannot express a
table of results, so each series here is a CSV under ``literature/data/series/``
plus one ``Provenance`` record. The CSVs are curated extracts of the source's
own published file: no value is typed by hand, and the extraction scripts and
raw downloads are recorded in each record's ``notes``.

Each series exposes ``provenance``, ``columns``, and ``entries`` (a tuple of
dicts, numeric fields as ``float``, empty cells as ``None``), plus ``list`` for
parity with the ``Registry`` convention. ``where(**match)`` filters entries on
exact field values.
"""
from __future__ import annotations

import csv
from pathlib import Path

from ..core.provenance import Provenance, ProvenanceKind

_SERIES = Path(__file__).parent / "data" / "series"

_EPOCH_HUB = "https://epoch.ai/benchmarks"
_EPOCH_LICENSE = "Epoch AI data, CC-BY 4.0 (credit Epoch AI)."


def _coerce(value: str):
    if value == "":
        return None
    if value in ("True", "False"):
        return value == "True"
    try:
        return float(value)
    except ValueError:
        return value


class _Series:
    """A provenance-carrying table loaded from one CSV."""

    def __init__(self, stem: str, provenance: Provenance, doc: str):
        self.__doc__ = doc
        self.provenance = provenance
        with open(_SERIES / f"{stem}.csv", newline="") as fh:
            reader = csv.DictReader(fh)
            self.columns = tuple(reader.fieldnames or ())
            self.entries = tuple({k: _coerce(v) for k, v in row.items()} for row in reader)
        self.list = self.entries

    def where(self, **match):
        return tuple(e for e in self.entries if all(e.get(k) == v for k, v in match.items()))

    def __len__(self):
        return len(self.entries)


AgentTimeHorizon = _Series(
    "metr_time_horizon_v1_1",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="METR, Time Horizon v1.1 benchmark results (50% task-completion horizon, minutes of expert human time)",
        url="https://metr.org/assets/benchmark_results_1_1.yaml",
        verified="2026-10-12",
        notes=(
            "Copied from METR's published YAML (benchmark METR-Horizon-v1.1). "
            "METR's stated 2023-on doubling time is 128.744 days (CI 104.4-158.0), "
            "fit on frontier models with p50 <= 16 h; refitting these rows the same "
            "way reproduces it."
        ),
    ),
    "50%-success task horizon by model release (METR Time Horizon v1.1).",
)

LowestPriceAtCapability = _Series(
    "epoch_lowest_price_at_capability",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Epoch AI, LLM inference price trends: cheapest model above each benchmark threshold",
        url="https://epoch.ai/data-insights/llm-inference-price-trends",
        verified="2026-10-12",
        notes=(
            "Chart data lowest_price_models_data.csv. Prices are a 3:1 weighted "
            "average of input and output token prices, first-party API where one "
            "exists, otherwise the median across providers (Epoch methodology). "
            "Series end February 2025. " + _EPOCH_LICENSE
        ),
    ),
    "Cheapest price (USD per million tokens) to reach a fixed benchmark level, by date.",
)

TerminalBenchHarness = _Series(
    "terminal_bench_2_harness",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Terminal-Bench 2.0 leaderboard (model x agent harness), via the Epoch AI Benchmarking Hub",
        url=_EPOCH_HUB,
        verified="2026-10-12",
        notes=(
            "Rows whose source is the Terminal-Bench 2.0 leaderboard "
            "(tbench.ai/leaderboard/terminal-bench/2.0); '_unknown' suffix removed "
            "from model ids; duplicate (model, harness) rows resolved to the latest "
            "run. " + _EPOCH_LICENSE
        ),
    ),
    "Terminal-Bench 2.0 accuracy for the same model under different agent harnesses.",
)

LongContextComprehension = _Series(
    "fiction_livebench_by_length",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Fiction.LiveBench long-context comprehension scores by context length, via the Epoch AI Benchmarking Hub",
        url=_EPOCH_HUB,
        verified="2026-10-12",
        notes="Scores copied per length column (0 to 192k tokens). " + _EPOCH_LICENSE,
    ),
    "Long-context comprehension accuracy by tokens of story placed in context.",
)

SweBenchVerifiedRuns = _Series(
    "epoch_swe_bench_verified_runs",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Epoch AI evaluations of SWE-bench Verified under one harness (mean score and standard error)",
        url=_EPOCH_HUB,
        verified="2026-10-12",
        notes="One row per model, highest-scoring run kept. " + _EPOCH_LICENSE,
    ),
    "SWE-bench Verified resolve fraction with standard error, one harness.",
)

CybenchSolveRate = _Series(
    "cybench_unguided",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Cybench unguided solve rate on 40 professional-level CTF tasks, via the Epoch AI Benchmarking Hub",
        url="https://cybench.github.io/",
        verified="2026-10-12",
        notes=(
            "Task count from cybench.github.io. The source column separates "
            "leaderboard entries from lab-reported model/system-card figures. "
            + _EPOCH_LICENSE
        ),
    ),
    "Fraction of Cybench CTF tasks solved without subtask hints, by model release.",
)

OSWorldStepBudget = _Series(
    "osworld_step_budget",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="OSWorld leaderboard results for the same model at 15, 50, and 100 step limits, via the Epoch AI Benchmarking Hub",
        url="https://os-world.github.io/",
        verified="2026-10-12",
        notes="Step limit parsed from the leaderboard agent label '(N steps)'. " + _EPOCH_LICENSE,
    ),
    "OSWorld task success (percent) by step ceiling, per model.",
)

FrontierSweTrials = _Series(
    "frontier_swe_v2_trials",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="FrontierSWE V2 leaderboard: mean, best, and worst of 5 trials, cost and duration per trial",
        url="https://www.frontierswe.com/",
        verified="2026-10-12",
        notes=(
            "34 tasks, 5 trials per task, 20-hour budget per trial; cost and time "
            "are per-trial averages (frontierswe.com). Values via the Epoch AI "
            "Benchmarking Hub. " + _EPOCH_LICENSE
        ),
    ),
    "Long-horizon software tasks: score spread over 5 trials, cost and hours per trial.",
)

SweBenchTrajectories = _Series(
    "swe_bench_verified_trajectories",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="SWE-bench Verified submission trajectories (SWE-agent, OpenHands, mini-SWE-agent), per-trajectory statistics",
        url="https://github.com/SWE-bench/experiments",
        verified="2026-10-12",
        notes=(
            "Five public submissions: 2,100 trajectories (500 each; the SWE-agent 1.1 "
            "run is a seed-0 random sample of 100). Trajectory files from the public "
            "swe-bench-submissions S3 bucket named in each submission's metadata; "
            "resolved flags from results/results.json at repo commit 40f164d5. "
            "Sizes are characters (no tokenizer), classified by message role: "
            "model output, environment observations, and prompt (system, "
            "demonstrations, task). Token and cost columns are copied as each "
            "agent recorded them; OpenHands records none."
        ),
    ),
    "Per-trajectory model calls, role-split characters, tokens, and cost for public repair-agent runs.",
)

_MONKEYS_NOTES = (
    "Brown et al. (2024), Large Language Monkeys. Recomputed from the released "
    "per-sample correctness labels: Hugging Face ScalingIntelligence/monkey_business "
    "@ a9f8f73b (10,000 samples per problem) and github.com/ScalingIntelligence/"
    "swe-bench-lite-samples @ 17594ed2 (250 samples per problem; crashed samples "
    "count as incorrect, per its README). Coverage is the unbiased pass@k estimator "
    "averaged over problems."
)

RepeatedSamplingCoverage = _Series(
    "repeated_sampling_coverage",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Large Language Monkeys repeated-sampling datasets: coverage (pass@k) vs. samples",
        url="https://arxiv.org/abs/2407.21787",
        verified="2026-10-12",
        notes=_MONKEYS_NOTES,
    ),
    "Fraction of problems with at least one correct sample among k, by model and dataset.",
)

RepeatedSamplingMajority = _Series(
    "repeated_sampling_majority",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Large Language Monkeys repeated-sampling datasets: majority-vote accuracy vs. samples (GSM8K, MATH)",
        url="https://arxiv.org/abs/2407.21787",
        verified="2026-10-12",
        notes=(
            _MONKEYS_NOTES + " Majority vote pools final answers extracted with the "
            "authors' GSM8K regex and the lm-eval Minerva MATH normalizer; small k is "
            "a Monte Carlo estimate over 200 draws. Normalization can only split "
            "equivalent answers, so these accuracies are if anything low."
        ),
    ),
    "Majority-vote accuracy alongside coverage at the same k (GSM8K, MATH).",
)

InjectionDefenseResults = _Series(
    "agentdojo_results",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="AgentDojo published results: benign utility, utility under attack, and targeted attack success by model and defense",
        url="https://agentdojo.spylab.ai/results/",
        verified="2026-10-12",
        notes=(
            "Parsed from docs/results-table.html at github.com/ethz-spylab/agentdojo @ "
            "089ed468 (identical to the live results page). The authors state it is "
            "not a leaderboard: only gpt-4o-2024-05-13 was run with every defense and "
            "attack; other models use the important_instructions attack and no "
            "defense. Release dates are omitted because one source date is a typo."
        ),
    ),
    "Prompt-injection benchmark: utility and attack success per model and defense.",
)

# ---------------------------------------------------------------------------
# Physical AI series (added 2026-10-12)
# ---------------------------------------------------------------------------

ModelsByDomain = _Series(
    "epoch_models_by_domain",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Epoch AI, Data on AI Models (all_ai_models.csv): training compute by domain (Robotics, Language, Vision)",
        url="https://epoch.ai/data/ai-models",
        verified="2026-10-12",
        notes=(
            "Rows with a training-compute estimate only. A model tagged with several "
            "domains appears once per matching domain_group. Compute values are Epoch's "
            "estimates (confidence column), not first-party measurements; Epoch tags NVIDIA "
            "Cosmos world models as Robotics. " + _EPOCH_LICENSE
        ),
    ),
    "Training compute (FLOP) and publication date of AI models, by domain group.",
)

OpenXEmbodimentComposition = _Series(
    "open_x_embodiment_composition",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Open X-Embodiment dataset overview spreadsheet: episodes, robot, morphology, control frequency per constituent dataset",
        url="https://github.com/google-deepmind/open_x_embodiment",
        verified="2026-10-12",
        notes=(
            "Exported from the official Google Sheet linked in the repository README "
            "(repo @ 9eeb68b9). 72 datasets; episode total 2,419,193 matches the sheet's own "
            "total. The sheet is a live document and cannot be pinned to a revision."
        ),
    ),
    "Composition of the Open X-Embodiment robot-learning collection.",
)

LeRobotHubMonthly = _Series(
    "lerobot_hub_monthly",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Hugging Face Hub API: datasets tagged LeRobot, new and cumulative count by creation month",
        url="https://huggingface.co/api/datasets?filter=LeRobot",
        verified="2026-10-12",
        notes=(
            "81 API pages (80,132 unique datasets). Counts include only datasets still public "
            "at fetch time, so earlier cumulative values are lower bounds."
        ),
    ),
    "Public LeRobot-format datasets on the Hugging Face Hub, by creation month.",
)

LeRobotEpisodeHistogram = _Series(
    "lerobot_hub_episode_histogram",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="Hugging Face Hub LeRobot datasets: episodes per dataset, power-of-two bins by creation year",
        url="https://huggingface.co/api/datasets?filter=LeRobot",
        verified="2026-10-12",
        notes=(
            "Episode counts parsed from each dataset card's embedded meta/info.json for the "
            "59,031 datasets that carry one; a 25-dataset spot check against info.json matched "
            "21 exactly (cards can lag the data). Bin b holds counts in [bin_lo, bin_hi)."
        ),
    ),
    "Distribution of episodes per public LeRobot dataset.",
)

EdgeInferenceOrin = _Series(
    "mlperf_inference_edge_orin",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="MLPerf Inference Edge, closed division, results for NVIDIA Orin-family systems (v3.1, v4.0, v4.1)",
        url="https://github.com/mlcommons/inference_results_v3.1",
        verified="2026-10-12",
        notes=(
            "Parsed from the mlcommons inference_results repositories (v3.1 @ f7b504d4, "
            "v4.0 @ 343c3d2c, v4.1 @ 198fc467), loadgen-valid results only. Single-stream "
            "latency metrics as reported (p50, p90 with early stopping)."
        ),
    ),
    "Measured inference latency and throughput on Orin-family edge systems.",
)

KittiOdometry = _Series(
    "kitti_odometry_leaderboard",
    Provenance(
        kind=ProvenanceKind.LITERATURE,
        ref="KITTI odometry benchmark leaderboard: translation and rotation error per method",
        url="https://www.cvlibs.net/datasets/kitti/eval_odometry.php",
        verified="2026-10-12",
        notes=(
            "127 methods. sensor_group comes from the page's sensor icons: stereo, laser, or "
            "none (a mix of monocular, some lidar-inertial, and event-camera methods). "
            "Runtimes are self-reported on different hardware."
        ),
    ),
    "Odometry drift (percent of distance) by method and sensor type.",
)

CaliforniaDisengagements = _Series(
    "ca_dmv_disengagements",
    Provenance(
        kind=ProvenanceKind.INDUSTRY_REPORT,
        ref="California DMV autonomous vehicle disengagement and mileage reports, per company, report year, and permit type",
        url="https://web.archive.org/web/20260519/https://www.dmv.ca.gov/portal/vehicle-industry-services/autonomous-vehicles/disengagement-reports/",
        verified="2026-10-12",
        notes=(
            "Report year runs Dec 1 to Nov 30. 2020 onward from the DMV consolidated "
            "CSVs (per-VIN rows summed per permit); 2019 from the DMV spreadsheets; "
            "earlier years from each company's filed PDF (text layer or OCR, as "
            "source_method records). What counts as a reportable disengagement is "
            "self-defined by each company under 13 CCR 227.50, and the DMV states the "
            "reports are not designed for comparison across companies. Commercial "
            "deployment miles are excluded by regulation. The live DMV page returned 404 "
            "on the fetch date; files came from the DMV-hosted bundle the archived page links."
        ),
    ),
    "Autonomous testing miles and reported disengagements filed with the California DMV.",
)

WaymoSafetyImpact = _Series(
    "waymo_safety_impact_headline",
    Provenance(
        kind=ProvenanceKind.INDUSTRY_REPORT,
        ref="Waymo Safety Impact data hub: rider-only crash rates vs. a location-adjusted human benchmark, by outcome and data cut",
        url="https://waymo.com/safety/impact/",
        verified="2026-10-12",
        notes=(
            "Rows: All Locations (mileage blended), All Crashes, dynamic (location-adjusted) "
            "benchmark built from 2022 human crash data. pct_reduction is the rate ratio "
            "minus one; 95% confidence intervals by the rate-ratio method the data "
            "dictionary cites. The 202606 cut uses the corrected v2 file the release notes "
            "name as the replacement. ro_miles_millions is cumulative rider-only miles "
            "through the cut (before 202512, the sum of operating-depot rows)."
        ),
    ),
    "Waymo rider-only crash-rate reductions with confidence intervals, by outcome and data cut.",
)


# ---------------------------------------------------------------------------
# Trend series behind Volume I and II figures, exposed as Literature.Series.<Name>.
# Merged 2026-10-12 from a parallel branch; the module-level series above are
# exposed as Literature.<Name>. Both share data/series/.
# ---------------------------------------------------------------------------
_DIR = Path(__file__).parent / "data" / "series"


class TrendSeries:
    """A provenance-carrying table loaded from ``data/series/<stem>.csv``.

    ``numeric`` names the columns parsed as floats; empty cells become ``None``.
    """

    def __init__(self, stem: str, provenance: Provenance, doc: str, numeric: tuple[str, ...] = ()):
        self.name = stem
        self.provenance = provenance
        self.__doc__ = doc
        rows = []
        with open(_DIR / f"{stem}.csv", newline="") as f:
            for raw in csv.DictReader(f):
                row = {}
                for k, v in raw.items():
                    if k in numeric:
                        row[k] = float(v) if v not in ("", None) else None
                    else:
                        row[k] = v
                rows.append(row)
        self.entries = tuple(rows)

    def column(self, key: str) -> list:
        """Return one column, in file order."""
        return [r[key] for r in self.entries]

    def __len__(self) -> int:
        return len(self.entries)

    def __repr__(self) -> str:
        return f"TrendSeries({self.name!r}, rows={len(self.entries)})"


def _lit(ref: str, url: str, notes: str | None = None) -> Provenance:
    return Provenance(kind=ProvenanceKind.LITERATURE, ref=ref, url=url, verified="2026-10-12", notes=notes)


class Series:
    """Namespace of dataset series (see module docstring)."""

    MicroprocessorTrends = TrendSeries(
        "microprocessor_trends",
        _lit("Karl Rupp, 50 Years of Microprocessor Trend Data (CC BY 4.0), 50yrs/*.dat",
             "https://github.com/karlrupp/microprocessor-trend-data",
             "series: transistors (thousands), specint (x1e3), frequency (MHz), watts, cores; 1971-2021"),
        "Microprocessor transistor count, single-thread performance, frequency, power, and cores by year.",
        numeric=("year", "value"),
    )
    StoragePricePerTB = TrendSeries(
        "storage_price_per_tb",
        _lit("Our World in Data, Historical price of computer memory and storage (CC BY 4.0), "
             "from John C. McCallum (2023) deflated with the U.S. BLS CPI",
             "https://ourworldindata.org/grapher/historical-cost-of-computer-memory-and-storage",
             "constant 2020 US$ per TB; each value is the lowest price recorded up to that year"),
        "Price per terabyte of DRAM, flash, solid-state drives, and hard disk drives, 1956-2023.",
        numeric=("year", "dram", "flash", "ssd", "hdd"),
    )
    TestSetLabelErrors = TrendSeries(
        "test_set_label_errors",
        _lit("Northcutt, Athalye, and Mueller (2021), Pervasive Label Errors in Test Sets Destabilize "
             "Machine Learning Benchmarks, Table 1", "https://arxiv.org/abs/2103.14749",
             "errors are human-validated except QuickDraw and Amazon Reviews (estimated=1), which "
             "extrapolate from a validated sample; ImageNet uses the ILSVRC 2012 validation set"),
        "Share of benchmark test-set labels found to be wrong, by dataset.",
        numeric=("test_size", "errors", "pct_error", "estimated"),
    )
    NotableModels = TrendSeries(
        "notable_models",
        _lit("Epoch AI, Notable AI Models database (CC BY 4.0), snapshot 2026-10-12",
             "https://epoch.ai/data/notable-ai-models",
             "training_cost_2023usd follows Cottier et al. (2024); frontier = Epoch's frontier-model flag"),
        "Parameters, training cost, domain, and publication date of notable models.",
        numeric=("parameters", "training_cost_2023usd", "frontier"),
    )
    PretrainingTokens = TrendSeries(
        "pretraining_tokens",
        _lit("Pre-training token counts as reported in each model's paper or release (see source column)",
             "https://arxiv.org/abs/2211.04325",
             "url points to Villalobos et al. (2024), whose stock estimate (about 3e14 tokens, 90% CI "
             "1e14-1e15) the figure overlays; per-model sources are in the CSV"),
        "Reported pre-training tokens for landmark language models, 2020-2025.",
        numeric=("tokens",),
    )
    PublicTextStock = TrendSeries(
        "public_text_stock",
        _lit("Villalobos et al. (2024), Will We Run Out of Data? Limits of LLM Scaling Based on "
             "Human-Generated Data (arXiv v2)", "https://arxiv.org/abs/2211.04325",
             "effective stock of quality- and repetition-adjusted public human text: median about "
             "3e14 tokens, 90% confidence interval 1e14 to 1e15"),
        "Estimated stock of public human-generated text (tokens): low, median, and high bounds.",
        numeric=("tokens",),
    )
    MMLUDenseModels = TrendSeries(
        "mmlu_dense_models",
        _lit("Epoch AI Benchmarking Hub, MMLU (external results) (CC BY 4.0), snapshot 2026-10-12",
             "https://epoch.ai/benchmarks",
             "parameter counts parsed from dense model names (for example '7B'); mixture-of-experts "
             "names excluded; scores as reported by each row's source"),
        "MMLU accuracy and parameter count of dense language models by release date.",
        numeric=("parameters", "mmlu"),
    )
    AcceleratorBandwidthCompute = TrendSeries(
        "accelerator_bandwidth_compute",
        _lit("Epoch AI, Machine Learning Hardware database (CC BY 4.0), snapshot 2026-10-12",
             "https://epoch.ai/data/machine-learning-hardware",
             "devices with >= 16 GB off-chip memory and a dense FP16/BF16 tensor rate; MI308X excluded "
             "(listed at 10.3 TB/s although it uses MI300X's 5.3 TB/s HBM3 stack)"),
        "Memory bandwidth and dense FP16/BF16 tensor throughput of ML accelerators by release date.",
        numeric=("memory_bandwidth_bytes_per_s", "fp16_tensor_flops", "memory_bytes"),
    )
    TemporalShiftWildTime = TrendSeries(
        "temporal_shift_wildtime",
        _lit("Yao et al. (2022), Wild-Time: A Benchmark of in-the-Wild Distribution Shift over Time, "
             "Table 1 (ERM, Eval-Fix, mean and std over three seeds)", "https://arxiv.org/abs/2211.14238"),
        "Performance on test data from the training period versus a later period, six datasets.",
        numeric=("id_mean", "id_std", "ood_mean", "ood_std"),
    )
    PyTorchOperatorSchemas = TrendSeries(
        "pytorch_operator_schemas",
        _lit("PyTorch aten/src/ATen/native/native_functions.yaml at each release tag (mined 2026-10-12)",
             "https://github.com/pytorch/pytorch/blob/main/aten/src/ATen/native/native_functions.yaml",
             "aten_schemas counts '- func:' entries including overloads; core_aten counts schemas tagged "
             "'core' (Core ATen IR), first tagged in v2.0; dates are GitHub release dates"),
        "PyTorch ATen operator schemas and Core ATen IR size by release.",
        numeric=("aten_schemas", "core_aten"),
    )
    TensorFlowOperators = TrendSeries(
        "tensorflow_operators",
        _lit("TensorFlow tensorflow/core/ops/ops.pbtxt at each release tag (mined 2026-10-12)",
             "https://github.com/tensorflow/tensorflow/blob/master/tensorflow/core/ops/ops.pbtxt",
             "ops counts registered op definitions ('op {' entries); dates are GitHub release dates; "
             "v1.15 omitted because it shipped after v2.0"),
        "Registered TensorFlow operators by release.",
        numeric=("ops",),
    )
    XLAHLOOpcodes = TrendSeries(
        "xla_hlo_opcodes",
        _lit("XLA hlo_opcode.h (HLO_OPCODE_LIST) as vendored in TensorFlow at each release tag (mined 2026-10-12)",
             "https://github.com/openxla/xla/blob/main/xla/hlo/ir/hlo_opcode.h",
             "opcodes counts V(k...) entries; XLA is the compiler that both TensorFlow and JAX lower to"),
        "Number of XLA HLO opcodes by TensorFlow release.",
        numeric=("opcodes",),
    )
    JAXLaxPrimitives = TrendSeries(
        "jax_lax_primitives",
        _lit("JAX jax/_src/lax/**/*.py at each release tag (mined 2026-10-12)",
             "https://github.com/jax-ml/jax/tree/main/jax/_src/lax",
             "primitives counts module-level '<name>_p = ...(' primitive objects, JAX's naming convention"),
        "Number of jax.lax primitives by JAX release.",
        numeric=("primitives",),
    )
    ONNXOpsetOperators = TrendSeries(
        "onnx_opset_operators",
        _lit("ONNX operator schemas with history (onnx 1.23.2, ai.onnx domain) and docs/Versioning.md",
             "https://github.com/onnx/onnx/blob/main/docs/Versioning.md",
             "operators counts distinct ai.onnx operators whose first since_version <= opset; "
             "date is the GitHub release that introduced the opset"),
        "Number of standard ONNX operators defined through each opset release.",
        numeric=("opset", "operators"),
    )
